using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using AcadClaude.Claude;

namespace AcadClaude.UI;

public class ChatView : UserControl
{
    private readonly StackPanel _log = new() { Margin = new Thickness(6) };
    private readonly ScrollViewer _scroll;
    private readonly TextBox _input;
    private readonly Button _send;
    private readonly ClaudeClient _client = new();

    public ChatView()
    {
        Background = Brushes.White;

        _scroll = new ScrollViewer { Content = _log, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };

        _input = new TextBox
        {
            AcceptsReturn = true,
            TextWrapping = TextWrapping.Wrap,
            MinHeight = 60,
            MaxHeight = 160,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto
        };
        _input.PreviewKeyDown += OnInputKey;

        _send = new Button { Content = "Gửi", Width = 60, Margin = new Thickness(4, 0, 0, 0) };
        _send.Click += async (_, _) => await SendAsync();

        var newChat = new Button { Content = "Hội thoại mới", Margin = new Thickness(6), Padding = new Thickness(8, 2, 8, 2), HorizontalAlignment = HorizontalAlignment.Left };
        newChat.Click += (_, _) => { _client.Reset(); _log.Children.Clear(); };

        var inputRow = new DockPanel { Margin = new Thickness(6) };
        DockPanel.SetDock(_send, Dock.Right);
        inputRow.Children.Add(_send);
        inputRow.Children.Add(_input);

        var root = new DockPanel();
        DockPanel.SetDock(newChat, Dock.Top);
        DockPanel.SetDock(inputRow, Dock.Bottom);
        root.Children.Add(newChat);
        root.Children.Add(inputRow);
        root.Children.Add(_scroll);
        Content = root;

        _client.OnText += t => Append("Claude", t, Brushes.Black);
        _client.OnToolCall += (name, result, err) =>
            Append($"🔧 {name}", Shorten(result), err ? Brushes.DarkRed : Brushes.SlateGray);
    }

    // Enter = gửi, Shift+Enter = xuống dòng
    private void OnInputKey(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter && Keyboard.Modifiers != ModifierKeys.Shift)
        {
            e.Handled = true;
            _ = SendAsync();
        }
    }

    private async Task SendAsync()
    {
        var text = _input.Text.Trim();
        if (text.Length == 0 || !_send.IsEnabled) return;

        _input.Clear();
        Append("Bạn", text, Brushes.DarkBlue);
        _send.IsEnabled = false;
        try { await _client.SendAsync(text); }
        catch (Exception ex) { Append("Lỗi", ex.Message, Brushes.DarkRed); }
        finally { _send.IsEnabled = true; _input.Focus(); }
    }

    private void Append(string who, string text, Brush color)
    {
        _log.Children.Add(new TextBox
        {
            Text = $"{who}:\n{text}",
            IsReadOnly = true,
            BorderThickness = new Thickness(0),
            Background = Brushes.Transparent,
            TextWrapping = TextWrapping.Wrap,
            Foreground = color,
            Margin = new Thickness(0, 0, 0, 8)
        });
        _scroll.ScrollToEnd();
    }

    private static string Shorten(string s) => s.Length > 500 ? s.Substring(0, 500) + " …" : s;
}
