using System.Globalization;
using System.Reflection;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Autodesk.AutoCAD.Runtime;
using Autodesk.Windows;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Application;

namespace AcadClaude.UI;

/// <summary>
/// Gắn lên một lệnh [CommandMethod] để lệnh đó tự có nút trên ribbon.
/// Ví dụ: [RibbonButton("Kết cấu", "Lưới\ntrục", Tab = "Kết Cấu", Icon = "#", Color = "#2E7D9A")]
/// </summary>
[AttributeUsage(AttributeTargets.Method)]
public class RibbonButtonAttribute : Attribute
{
    public RibbonButtonAttribute(string panel, string text) { Panel = panel; Text = text; }
    public string Panel { get; }              // tên panel (nhóm) trong tab
    public string Text { get; }               // chữ trên nút, \n để xuống dòng (nút lớn)
    public string? Tab { get; set; }          // tên tab; bỏ trống = theo [RibbonTab] của class, hoặc "Claude AI"
    public string Tooltip { get; set; } = "";
    public string Icon { get; set; } = "?";   // 1-2 ký tự vẽ trên icon
    public string Color { get; set; } = "#5B6B7A";
    public bool Large { get; set; } = true;   // false = nút nhỏ, xếp 3 nút/cột
    public int Order { get; set; }            // thứ tự trong panel
    public string? Group { get; set; }        // cùng Panel + cùng Group = gộp thành 1 nút dropdown; click mở danh sách các tool
    public string GroupIcon { get; set; } = "≡"; // icon của nút gộp (lấy theo nút đầu tiên trong nhóm có khai báo)
}

/// <summary>
/// Gắn lên class chứa lệnh: mọi nút trong class mặc định nằm ở tab này.
/// Ví dụ: [RibbonTab("Kết Cấu")]
/// </summary>
[AttributeUsage(AttributeTargets.Class)]
public class RibbonTabAttribute : Attribute
{
    public RibbonTabAttribute(string title) { Title = title; }
    public string Title { get; }
}

public static class RibbonSetup
{
    private const string DefaultTab = "Claude AI";

    // Thứ tự tab và panel; tên không có trong danh sách sẽ đứng sau, theo thứ tự chữ cái
    private static readonly string[] TabOrder = { "Claude AI", "Kết Cấu", "Template CAD" };
    private static readonly string[] PanelOrder = { "Trợ lý AI", "Kết cấu", "Tiện ích", "Cài đặt", "Thiết lập", "Khung tên", "Template", "Ký hiệu" };

    private record ButtonDef(string Tab, RibbonButtonAttribute A, string Cmd);

    public static void Init()
    {
        if (ComponentManager.Ribbon != null) AddTabs();
        else ComponentManager.ItemInitialized += OnItemInitialized;

        AcApp.SystemVariableChanged += (_, e) =>
        {
            if (e.Name.Equals("WSCURRENT", StringComparison.OrdinalIgnoreCase)) AddTabs();
        };
    }

    private static void OnItemInitialized(object? sender, RibbonItemEventArgs e)
    {
        if (ComponentManager.Ribbon == null) return;
        ComponentManager.ItemInitialized -= OnItemInitialized;
        AddTabs();
    }

    // Các nút cho lệnh có sẵn trong Plugin.cs
    private static IEnumerable<ButtonDef> BuiltIn()
    {
        yield return new(DefaultTab, new RibbonButtonAttribute("Trợ lý AI", "Chat\nClaude")
            { Tooltip = "Mở palette chat với Claude và chạy thử tool", Icon = "AI", Color = "#D97757" }, "CLAUDE");
        yield return new(DefaultTab, new RibbonButtonAttribute("Cài đặt", "API key")
            { Tooltip = "Nhập hoặc đổi Anthropic API key", Icon = "K", Large = false, Order = 0 }, "CLAUDEKEY");
        yield return new(DefaultTab, new RibbonButtonAttribute("Cài đặt", "Đổi model")
            { Tooltip = "Chọn model Claude", Icon = "M", Large = false, Order = 1 }, "CLAUDEMODEL");
        yield return new(DefaultTab, new RibbonButtonAttribute("Cài đặt", "Bật/tắt MCP")
            { Tooltip = "Bật hoặc tắt cổng MCP cho Claude Desktop / Claude Code", Icon = "MC", Large = false, Order = 2 }, "CLAUDEMCP");
    }

    // Tự tìm mọi lệnh có gắn [RibbonButton] trong plugin
    private static IEnumerable<ButtonDef> Discovered()
    {
        foreach (var type in typeof(RibbonSetup).Assembly.GetTypes())
        {
            var classTab = type.GetCustomAttribute<RibbonTabAttribute>()?.Title;
            foreach (var m in type.GetMethods(BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static))
            {
                var rb = m.GetCustomAttribute<RibbonButtonAttribute>();
                var cm = m.GetCustomAttribute<CommandMethodAttribute>();
                if (rb == null || cm == null) continue;
                yield return new(rb.Tab ?? classTab ?? DefaultTab, rb, cm.GlobalName);
            }
        }
    }

    private static int Rank(string[] order, string name) =>
        Array.IndexOf(order, name) is var i && i >= 0 ? i : 99;

    private static void AddTabs()
    {
        var ribbon = ComponentManager.Ribbon;
        if (ribbon == null) return;

        var tabs = BuiltIn().Concat(Discovered())
            .GroupBy(b => b.Tab)
            .OrderBy(g => Rank(TabOrder, g.Key)).ThenBy(g => g.Key);

        foreach (var tabGroup in tabs)
        {
            var tabId = "ACADCLAUDE_" + tabGroup.Key.GetHashCode().ToString("X");
            if (ribbon.FindTab(tabId) != null) continue;   // đã có thì bỏ qua

            var tab = new RibbonTab { Title = tabGroup.Key, Id = tabId };
            ribbon.Tabs.Add(tab);

            var panels = tabGroup.GroupBy(b => b.A.Panel)
                .OrderBy(g => Rank(PanelOrder, g.Key)).ThenBy(g => g.Key);

            foreach (var g in panels)
            {
                var src = new RibbonPanelSource { Title = g.Key };
                var items = g.OrderBy(b => b.A.Order).ThenBy(b => b.A.Text).ToList();

                // Các nút cùng Group gộp thành 1 nút dropdown (không tách phần click chính, click là mở danh sách)
                foreach (var grp in items.Where(b => b.A.Group != null).GroupBy(b => b.A.Group!))
                    src.Items.Add(MakeGroupButton(grp.Key, grp.ToList()));

                foreach (var b in items.Where(b => b.A.Group == null && b.A.Large))
                    src.Items.Add(MakeButton(b.A, b.Cmd, large: true));

                var smalls = items.Where(b => b.A.Group == null && !b.A.Large).ToList();
                for (int i = 0; i < smalls.Count; i += 3)
                {
                    var row = new RibbonRowPanel();
                    foreach (var b in smalls.Skip(i).Take(3))
                    {
                        if (row.Items.Count > 0) row.Items.Add(new RibbonRowBreak());
                        row.Items.Add(MakeButton(b.A, b.Cmd, large: false));
                    }
                    src.Items.Add(row);
                }

                tab.Panels.Add(new RibbonPanel { Source = src });
            }
        }
    }

    private static RibbonSplitButton MakeGroupButton(string title, List<ButtonDef> members)
    {
        var first = members[0].A;
        var color = (Color)ColorConverter.ConvertFromString(first.Color);
        var split = new RibbonSplitButton
        {
            Text = title,
            ShowText = true,
            ShowImage = true,
            Size = RibbonItemSize.Large,
            Orientation = System.Windows.Controls.Orientation.Vertical,
            LargeImage = MakeIcon(first.GroupIcon, color, 32),
            Image = MakeIcon(first.GroupIcon, color, 16),
            IsSplit = false,                    // click vào nút = mở danh sách, không chạy lệnh nào
            IsSynchronizedWithCurrentItem = false,   // nút không đổi tên/icon theo tool vừa chọn
            ToolTip = new RibbonToolTip { Title = title, Content = string.Join(", ", members.Select(m => m.A.Text.Replace("\n", " "))) }
        };
        foreach (var m in members)
            split.Items.Add(MakeButton(m.A, m.Cmd, large: false));
        return split;
    }

    private static RibbonButton MakeButton(RibbonButtonAttribute a, string cmd, bool large)
    {
        var color = (Color)ColorConverter.ConvertFromString(a.Color);
        return new RibbonButton
        {
            Text = large ? a.Text : a.Text.Replace("\n", " "),
            ShowText = true,
            ShowImage = true,
            Size = large ? RibbonItemSize.Large : RibbonItemSize.Standard,
            Orientation = large ? System.Windows.Controls.Orientation.Vertical : System.Windows.Controls.Orientation.Horizontal,
            LargeImage = MakeIcon(a.Icon, color, 32),
            Image = MakeIcon(a.Icon, color, 16),
            ToolTip = new RibbonToolTip { Title = a.Text.Replace("\n", " "), Content = a.Tooltip, Command = cmd },
            CommandParameter = cmd,
            CommandHandler = new RibbonCommandHandler()
        };
    }

    /// <summary>Vẽ icon bằng code (hình vuông bo góc + chữ) để không cần file ảnh.</summary>
    private static ImageSource MakeIcon(string label, Color color, int size)
    {
        var visual = new DrawingVisual();
        using (var dc = visual.RenderOpen())
        {
            double r = size / 5.0;
            dc.DrawRoundedRectangle(new SolidColorBrush(color), null, new Rect(0.5, 0.5, size - 1, size - 1), r, r);
            var ft = new FormattedText(label, CultureInfo.InvariantCulture, FlowDirection.LeftToRight,
                new Typeface(new FontFamily("Segoe UI"), FontStyles.Normal, FontWeights.Bold, FontStretches.Normal),
                size * (label.Length > 1 ? 0.42 : 0.55), Brushes.White, 1.0);
            dc.DrawText(ft, new Point((size - ft.Width) / 2, (size - ft.Height) / 2));
        }
        var bmp = new RenderTargetBitmap(size, size, 96, 96, PixelFormats.Pbgra32);
        bmp.Render(visual);
        bmp.Freeze();
        return bmp;
    }

    private class RibbonCommandHandler : ICommand
    {
        public event EventHandler? CanExecuteChanged { add { } remove { } }
        public bool CanExecute(object? parameter) => true;

        public void Execute(object? parameter)
        {
            if (parameter is RibbonButton { CommandParameter: string cmd })
                AcApp.DocumentManager.MdiActiveDocument?
                    .SendStringToExecute("\x03\x03_" + cmd + " ", true, false, true);
        }
    }
}
