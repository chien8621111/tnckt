using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using AcadClaude.Tools;

namespace AcadClaude.UI;

/// <summary>Tab chạy thử từng tool với input JSON, dùng khi phát triển tool mới.</summary>
public class ToolsView : UserControl
{
    public ToolsView()
    {
        Background = Brushes.White;
        var mono = new FontFamily("Consolas");

        var list = new ListBox { ItemsSource = ToolRegistry.Tools.Keys.OrderBy(k => k).ToList(), Height = 150 };
        var desc = new TextBox { IsReadOnly = true, TextWrapping = TextWrapping.Wrap, Height = 140, FontFamily = mono, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        var input = new TextBox { Text = "{}", AcceptsReturn = true, Height = 90, FontFamily = mono, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        var run = new Button { Content = "Chạy thử", Margin = new Thickness(0, 6, 0, 6), Padding = new Thickness(8, 2, 8, 2), HorizontalAlignment = HorizontalAlignment.Left };
        var output = new TextBox { IsReadOnly = true, TextWrapping = TextWrapping.Wrap, MinHeight = 120, FontFamily = mono, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };

        list.SelectionChanged += (_, _) =>
        {
            if (list.SelectedItem is not string name) return;
            var tool = ToolRegistry.Tools[name];
            desc.Text = tool.Description + "\n\n" +
                        tool.InputSchema.ToJsonString(new JsonSerializerOptions { WriteIndented = true });
        };

        run.Click += (_, _) =>
        {
            if (list.SelectedItem is not string name) { output.Text = "Chọn một tool trước."; return; }
            try
            {
                using var jd = JsonDocument.Parse(input.Text);
                output.Text = ToolRegistry.Run(name, jd.RootElement.Clone());
            }
            catch (Exception ex) { output.Text = "Lỗi: " + ex.Message; }
        };

        var panel = new StackPanel { Margin = new Thickness(6) };
        panel.Children.Add(new TextBlock { Text = "Tools", FontWeight = FontWeights.Bold });
        panel.Children.Add(list);
        panel.Children.Add(new TextBlock { Text = "Mô tả & schema", FontWeight = FontWeights.Bold, Margin = new Thickness(0, 6, 0, 0) });
        panel.Children.Add(desc);
        panel.Children.Add(new TextBlock { Text = "Input (JSON)", FontWeight = FontWeights.Bold, Margin = new Thickness(0, 6, 0, 0) });
        panel.Children.Add(input);
        panel.Children.Add(run);
        panel.Children.Add(output);

        Content = new ScrollViewer { Content = panel, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
    }
}
