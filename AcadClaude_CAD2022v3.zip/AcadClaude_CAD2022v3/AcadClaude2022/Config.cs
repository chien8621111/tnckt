using System.Text.Json.Nodes;

namespace AcadClaude;

/// <summary>Cấu hình lưu tại %APPDATA%\AcadClaude\config.json</summary>
public static class Config
{
    private static readonly string Dir =
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "AcadClaude");
    private static readonly string FilePath = Path.Combine(Dir, "config.json");

    public static string ApiKey
    {
        // Biến môi trường ANTHROPIC_API_KEY được ưu tiên nếu có
        get => Environment.GetEnvironmentVariable("ANTHROPIC_API_KEY") ?? Get("apiKey") ?? "";
        set => Set("apiKey", value);
    }

    /// <summary>Token bảo vệ cổng MCP nội bộ; app AcadMcpBridge đọc cùng file này.</summary>
    public static string McpToken
    {
        get
        {
            var t = Get("mcpToken");
            if (string.IsNullOrEmpty(t)) { t = Guid.NewGuid().ToString("N"); Set("mcpToken", t); }
            return t!;
        }
    }

    public static string Model
    {
        get => Get("model") ?? "claude-sonnet-5-5";
        set => Set("model", value);
    }

    private static JsonObject Load()
    {
        try { return File.Exists(FilePath) ? JsonNode.Parse(File.ReadAllText(FilePath))!.AsObject() : new JsonObject(); }
        catch { return new JsonObject(); }
    }

    private static string? Get(string key) => (string?)Load()[key];

    private static void Set(string key, string value)
    {
        var obj = Load();
        obj[key] = value;
        Directory.CreateDirectory(Dir);
        File.WriteAllText(FilePath, obj.ToJsonString());
    }
}
