# AcadClaude: add-in Claude cho AutoCAD (bản AutoCAD 2021 - 2024, .NET Framework 4.8)

## Cấu trúc
```
AcadClaude/
├── AcadClaude.csproj        # .NET Framework 4.8, tham chiếu accoremgd/acdbmgd/acmgd
├── Plugin.cs                # Lệnh CLAUDE, CLAUDEKEY, CLAUDEMODEL; tạo palette
├── Config.cs                # API key + model lưu ở %APPDATA%\AcadClaude\config.json
├── Claude/ClaudeClient.cs   # Gọi Anthropic API, vòng lặp tool use
├── Tools/ToolBase.cs        # ITool, ToolBase (tiện ích), ToolRegistry (tự phát hiện tool)
├── Tools/DrawingTools.cs    # Các tool mẫu: đọc bản vẽ, layer, line, polyline, circle, text, xóa, zoom
├── UI/ChatView.cs           # Tab Chat
├── UI/ToolsView.cs          # Tab Tools: chạy thử từng tool
└── bundle/                  # Đóng gói để AutoCAD tự nạp
```

## Build và chạy
1. Cài Visual Studio 2022 (workload .NET desktop development, có kèm .NET Framework 4.8 targeting pack).
2. Không cần sửa đường dẫn AutoCAD: thư viện AutoCAD được tải từ NuGet khi build (cần internet lần đầu).
3. Build: `dotnet build -c Release`
4. Trong AutoCAD: `NETLOAD` → chọn `bin\Release\net48\AcadClaude.dll (các DLL System.*.dll đi kèm phải nằm cùng thư mục)`
5. Gõ `CLAUDEKEY` để nhập API key (lấy tại console.anthropic.com), rồi gõ `CLAUDE` để mở palette.

Để debug trong Visual Studio: Project Properties → Debug → Launch: Executable → trỏ tới `acad.exe`.

## Viết tool mới
Tạo một class kế thừa `ToolBase` ở bất kỳ file nào trong project. Ví dụ:

```csharp
public class DrawColumnGridTool : ToolBase
{
    public override string Name => "draw_column_grid";
    public override string Description => "Vẽ lưới cột chữ nhật b x h tại các giao điểm trục.";
    protected override string SchemaJson => """
    {"type":"object","properties":{
      "xs":{"type":"array","items":{"type":"number"}},
      "ys":{"type":"array","items":{"type":"number"}},
      "b":{"type":"number"},"h":{"type":"number"},
      "layer":{"type":"string"}},"required":["xs","ys","b","h"]}
    """;

    public override string Execute(JsonElement i, Document doc)
    {
        // dùng 1 transaction cho toàn bộ cột -> nhanh, và chỉ là 1 bước Undo
        ...
        return Json(new { created = count });
    }
}
```
Build lại và NETLOAD lại (hoặc khởi động lại AutoCAD). Tool mới tự xuất hiện trong tab Tools và Claude dùng được ngay.

Mẹo:
- Description là thứ Claude đọc để quyết định gọi tool nào. Hãy ghi rõ đơn vị, quy ước và khi nào nên dùng.
- Ưu tiên tool xử lý hàng loạt (nhận danh sách) thay vì để Claude gọi hàng trăm lần.
- Tool trả về kết quả gọn: số lượng, handle, lỗi. Không trả hàng nghìn dòng.

## Lưu ý bảo mật
API key được lưu dạng văn bản thường trong `%APPDATA%`. Nếu triển khai cho cả công ty, nên dựng một proxy server nội bộ giữ key, để add-in gọi qua proxy đó.
