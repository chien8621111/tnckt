using System.Net;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Windows.Threading;
using AcadClaude.Tools;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Application;

namespace AcadClaude.Mcp;

/// <summary>
/// Cổng HTTP nội bộ (chỉ localhost) để app AcadMcpBridge gọi tool trong AutoCAD.
///   GET  /status  -> trạng thái, bản vẽ đang mở
///   GET  /tools   -> danh sách tool (format Anthropic API)
///   POST /call    -> {"name": "...", "input": {...}} chạy tool trên bản vẽ đang mở
/// Mọi request phải có header X-AcadClaude-Token (lấy từ %APPDATA%\AcadClaude\config.json).
/// </summary>
public static class BridgeServer
{
    public const int Port = 8765;
    private static HttpListener? _listener;
    private static Dispatcher? _ui;

    public static bool IsRunning => _listener?.IsListening == true;

    /// <summary>Phải gọi từ main thread của AutoCAD.</summary>
    public static void Start()
    {
        if (IsRunning) return;
        _ui = Dispatcher.CurrentDispatcher;
        _ = Config.McpToken; // tạo token nếu chưa có
        _listener = new HttpListener();
        _listener.Prefixes.Add($"http://localhost:{Port}/");
        _listener.Start();
        Task.Run(LoopAsync);
    }

    public static void Stop()
    {
        try { _listener?.Stop(); _listener?.Close(); } catch { }
        _listener = null;
    }

    private static async Task LoopAsync()
    {
        while (_listener?.IsListening == true)
        {
            HttpListenerContext ctx;
            try { ctx = await _listener.GetContextAsync(); }
            catch { break; }
            _ = Task.Run(() => Handle(ctx));
        }
    }

    private static void Handle(HttpListenerContext ctx)
    {
        int status = 200;
        JsonNode body;
        try
        {
            var path = ctx.Request.Url?.AbsolutePath ?? "";
            if (ctx.Request.Headers["X-AcadClaude-Token"] != Config.McpToken)
            {
                status = 401;
                body = new JsonObject { ["ok"] = false, ["error"] = "Sai token" };
            }
            else if (ctx.Request.HttpMethod == "GET" && path == "/status")
            {
                var docName = OnUi(() => AcApp.DocumentManager.MdiActiveDocument?.Name ?? "");
                body = new JsonObject { ["ok"] = true, ["document"] = docName, ["tools"] = ToolRegistry.Tools.Count };
            }
            else if (ctx.Request.HttpMethod == "GET" && path == "/tools")
            {
                body = ToolRegistry.ToApiTools();
            }
            else if (ctx.Request.HttpMethod == "POST" && path == "/call")
            {
                string text;
                using (var sr = new StreamReader(ctx.Request.InputStream, Encoding.UTF8)) text = sr.ReadToEnd();
                using var doc = JsonDocument.Parse(text);
                var name = doc.RootElement.GetProperty("name").GetString()!;
                var input = doc.RootElement.TryGetProperty("input", out var i) ? i.Clone() : JsonDocument.Parse("{}").RootElement.Clone();

                var output = OnUi(() =>
                {
                    var result = ToolRegistry.Run(name, input);
                    AcApp.UpdateScreen(); // cập nhật màn hình sau khi vẽ
                    return result;
                });
                body = new JsonObject { ["ok"] = true, ["output"] = output };
            }
            else
            {
                status = 404;
                body = new JsonObject { ["ok"] = false, ["error"] = "Không có endpoint này" };
            }
        }
        catch (System.Exception ex)
        {
            body = new JsonObject { ["ok"] = false, ["error"] = ex.Message };
        }

        try
        {
            var bytes = Encoding.UTF8.GetBytes(body.ToJsonString());
            ctx.Response.StatusCode = status;
            ctx.Response.ContentType = "application/json; charset=utf-8";
            ctx.Response.ContentLength64 = bytes.Length;
            ctx.Response.OutputStream.Write(bytes, 0, bytes.Length);
            ctx.Response.OutputStream.Close();
        }
        catch { /* client đã ngắt */ }
    }

    /// <summary>Chạy hàm trên main thread của AutoCAD và chờ kết quả.</summary>
    private static string OnUi(Func<string> f)
    {
        string? result = null;
        System.Exception? error = null;
        var op = _ui!.BeginInvoke(new Action(() =>
        {
            try { result = f(); }
            catch (System.Exception e) { error = e; }
        }));
        if (op.Wait(TimeSpan.FromSeconds(120)) != DispatcherOperationStatus.Completed)
        {
            op.Abort();
            throw new TimeoutException("AutoCAD không phản hồi. Có thể đang chạy một lệnh, hãy bấm Esc trong AutoCAD rồi thử lại.");
        }
        if (error != null) throw error;
        return result ?? "";
    }
}
