using Autodesk.AutoCAD.ApplicationServices;   // extension DocumentCollection.Add(path)
using Autodesk.AutoCAD.Colors;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;
using AcadClaude.UI;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Application;
using FontDescriptor = Autodesk.AutoCAD.GraphicsInterface.FontDescriptor;
using Polyline = Autodesk.AutoCAD.DatabaseServices.Polyline;

[assembly: CommandClass(typeof(AcadClaude.Template.TemplateCommands))]

namespace AcadClaude.Template;

/// <summary>
/// Bộ template CAD: thiết lập chuẩn (layer, text style, dimstyle), khung tên, mở file .dwt, ký hiệu chuẩn.
/// Toàn bộ nút nằm ở tab "Template CAD". Đơn vị bản vẽ là mm; kích thước ký hiệu/khung tính theo mm trên giấy x tỉ lệ in.
/// </summary>
[RibbonTab("Template CAD")]
public class TemplateCommands
{
    private const string TextStyleName = "RFR-ARIAL";
    private static int _lastScale = 100;   // tỉ lệ 1:N dùng chung cho các lệnh, nhớ giữa các lần chạy

    private static readonly (string name, short color, string lt)[] Layers =
    {
        ("S-GRID", 8, "CENTER"), ("S-COLS", 1, "Continuous"), ("S-BEAM", 3, "Continuous"),
        ("S-WALL", 2, "Continuous"), ("S-SLAB", 4, "Continuous"), ("S-REBAR", 5, "Continuous"),
        ("S-HIDD", 8, "DASHED"), ("S-CENT", 1, "CENTER"), ("S-TEXT", 7, "Continuous"),
        ("S-ANNO", 7, "Continuous"), ("S-DIMS", 6, "Continuous"), ("S-HATCH", 9, "Continuous"),
        ("S-TITLE", 7, "Continuous")
    };

    private static readonly int[] DimScales = { 20, 25, 50, 75, 100, 150, 200, 500 };

    // ===================== THIẾT LẬP CHUẨN =====================

    [CommandMethod("AC_SETUP")]
    [RibbonButton("Thiết lập", "Thiết lập\nchuẩn", Order = 0, Icon = "S", Color = "#2E7D9A",
        Tooltip = "Đặt đơn vị mm; tạo bộ layer chuẩn, text style RFR-ARIAL (Arial, tiếng Việt) và dimstyle RFR-1_N cho các tỉ lệ 1:20...1:500")]
    public void Setup()
    {
        var doc = AcApp.DocumentManager.MdiActiveDocument;
        var ed = doc.Editor;
        var db = doc.Database;

        var scale = AskScale(ed);
        if (scale == null) return;

        using var tr = db.TransactionManager.StartTransaction();

        // Layer
        foreach (var (n, c, lt) in Layers) EnsureLayer(tr, db, n, c, lt);

        // Text style
        var tst = (TextStyleTable)tr.GetObject(db.TextStyleTableId, OpenMode.ForRead);
        ObjectId textStyleId;
        if (tst.Has(TextStyleName)) textStyleId = tst[TextStyleName];
        else
        {
            tst.UpgradeOpen();
            var ts = new TextStyleTableRecord { Name = TextStyleName, FileName = "arial.ttf", XScale = 1.0 };
            ts.Font = new FontDescriptor("Arial", false, false, 0, 0);
            textStyleId = tst.Add(ts);
            tr.AddNewlyCreatedDBObject(ts, true);
        }

        // Dimstyle cho từng tỉ lệ
        var dst = (DimStyleTable)tr.GetObject(db.DimStyleTableId, OpenMode.ForRead);
        int created = 0;
        foreach (var s in DimScales)
        {
            string name = $"RFR-1_{s}";
            if (dst.Has(name)) continue;
            dst.UpgradeOpen();
            var d = new DimStyleTableRecord
            {
                Name = name,
                Dimscale = s,
                Dimtxt = 2.5,          // chiều cao chữ trên giấy (mm)
                Dimtsz = 1.5,          // gạch chéo thay mũi tên (kiểu kiến trúc)
                Dimexe = 1.5,
                Dimexo = 1.0,
                Dimdle = 1.5,
                Dimgap = 1.0,
                Dimtad = 1,            // chữ nằm trên đường dim
                Dimtih = false,
                Dimtoh = false,
                Dimdec = 0,
                Dimtxsty = textStyleId
            };
            dst.Add(d);
            tr.AddNewlyCreatedDBObject(d, true);
            created++;
        }

        // Đặt hiện hành: đơn vị mm, text style, dimstyle theo tỉ lệ đã chọn
        db.Insunits = UnitsValue.Millimeters;
        db.Textstyle = textStyleId;
        string curName = $"RFR-1_{scale}";
        if (dst.Has(curName))
        {
            db.Dimstyle = dst[curName];
            db.SetDimstyleData((DimStyleTableRecord)tr.GetObject(dst[curName], OpenMode.ForRead));
        }

        tr.Commit();
        _lastScale = scale.Value;
        ed.WriteMessage($"\nĐã thiết lập: {Layers.Length} layer, text style {TextStyleName}, tạo {created} dimstyle mới, hiện hành tỉ lệ 1:{scale}" +
                        (dst.Has(curName) ? "." : $" (chưa có dimstyle 1:{scale}; dùng dimstyle hiện tại)."));
    }

    // ===================== KHUNG TÊN =====================

    [CommandMethod("AC_FRAME")]
    [RibbonButton("Khung tên", "Khung\nbản vẽ", Order = 0, Icon = "KH", Color = "#B5452F",
        Tooltip = "Vẽ khung bản vẽ A0-A4 theo tỉ lệ + bảng tên (dự án, tên bản vẽ, tỉ lệ, ngày, số bản vẽ) trên layer S-TITLE")]
    public void DrawFrame()
    {
        var doc = AcApp.DocumentManager.MdiActiveDocument;
        var ed = doc.Editor;
        var db = doc.Database;

        var kw = new PromptKeywordOptions("\nKhổ giấy [A0/A1/A2/A3/A4]", "A0 A1 A2 A3 A4") { AllowNone = true };
        kw.Keywords.Default = "A1";
        var kr = ed.GetKeywords(kw);
        if (kr.Status != PromptStatus.OK) return;
        string paper = kr.StringResult;

        var scale = AskScale(ed);
        if (scale == null) return;
        var project = AskString(ed, "\nTên dự án", "DỰ ÁN");
        if (project == null) return;
        var drawing = AskString(ed, "\nTên bản vẽ", "MẶT BẰNG KẾT CẤU");
        if (drawing == null) return;
        var number = AskString(ed, "\nSố bản vẽ", "KC-01");
        if (number == null) return;

        var pr = ed.GetPoint("\nĐiểm góc dưới-trái của khung: ");
        if (pr.Status != PromptStatus.OK) return;
        var o = pr.Value.TransformBy(ed.CurrentUserCoordinateSystem);

        var (w, h) = paper switch
        {
            "A0" => (1189.0, 841.0),
            "A2" => (594.0, 420.0),
            "A3" => (420.0, 297.0),
            "A4" => (297.0, 210.0),
            _ => (841.0, 594.0)
        };
        double s = scale.Value;

        using var tr = db.TransactionManager.StartTransaction();
        var ms = ModelSpace(tr, db);
        var lay = EnsureLayer(tr, db, "S-TITLE", 7, "Continuous");
        var style = TextStyleId(tr, db);

        // Khung ngoài (mép giấy) và khung trong (lề trái 25, các lề khác 5)
        Rect(tr, ms, db, lay, o.X, o.Y, o.X + w * s, o.Y + h * s);
        double ix0 = o.X + 25 * s, iy0 = o.Y + 5 * s, ix1 = o.X + (w - 5) * s, iy1 = o.Y + (h - 5) * s;
        Rect(tr, ms, db, lay, ix0, iy0, ix1, iy1);

        // Bảng tên 180 x 40 mm góc dưới-phải khung trong, 4 hàng x 10mm
        double tw = 180 * s, th = 40 * s, row = 10 * s;
        double tx0 = ix1 - tw, ty0 = iy0;
        Rect(tr, ms, db, lay, tx0, ty0, ix1, ty0 + th);
        for (int i = 1; i < 4; i++) Seg(tr, ms, db, lay, tx0, ty0 + i * row, ix1, ty0 + i * row);
        // Hàng dưới cùng chia 3 ô: TỈ LỆ | NGÀY | SỐ BV
        Seg(tr, ms, db, lay, tx0 + tw / 3, ty0, tx0 + tw / 3, ty0 + row);
        Seg(tr, ms, db, lay, tx0 + 2 * tw / 3, ty0, tx0 + 2 * tw / 3, ty0 + row);

        double big = 3.5 * s, small = 2.5 * s, pad = 2 * s, ty = 3 * s;
        Txt(tr, ms, db, lay, style, "RFR STRUCTURAL", tx0 + pad, ty0 + 3 * row + ty, big);
        Txt(tr, ms, db, lay, style, project, tx0 + pad, ty0 + 2 * row + ty, big);
        Txt(tr, ms, db, lay, style, drawing, tx0 + pad, ty0 + row + ty, big);
        Txt(tr, ms, db, lay, style, $"TỈ LỆ: 1:{scale}", tx0 + pad, ty0 + ty, small);
        Txt(tr, ms, db, lay, style, $"NGÀY: {DateTime.Now:dd/MM/yyyy}", tx0 + tw / 3 + pad, ty0 + ty, small);
        Txt(tr, ms, db, lay, style, $"SỐ BV: {number}", tx0 + 2 * tw / 3 + pad, ty0 + ty, small);

        tr.Commit();
        _lastScale = scale.Value;
        ed.WriteMessage($"\nĐã vẽ khung {paper} tỉ lệ 1:{scale} ({w * s:N0} x {h * s:N0} mm).");
    }

    // ===================== MỞ FILE .DWT =====================

    [CommandMethod("AC_DWT", CommandFlags.Session)]
    [RibbonButton("Template", "Tạo từ\nfile .dwt", Order = 0, Icon = "DWT", Color = "#6A7F3A",
        Tooltip = "Chọn một file template .dwt (mặc định thư mục %APPDATA%\\AcadClaude\\Templates) để tạo bản vẽ mới")]
    public void NewFromDwt()
    {
        var ed = AcApp.DocumentManager.MdiActiveDocument.Editor;
        string folder = TemplateFolder();

        var opts = new PromptOpenFileOptions("\nChọn file template (.dwt)")
        {
            Filter = "Template AutoCAD (*.dwt)|*.dwt|Bản vẽ (*.dwg)|*.dwg",
            InitialDirectory = folder,
            PreferCommandLine = false
        };
        var res = ed.GetFileNameForOpen(opts);
        if (res.Status != PromptStatus.OK) return;

        AcApp.DocumentManager.Add(res.StringResult);   // tạo bản vẽ mới từ template
    }

    [CommandMethod("AC_DWTFOLDER")]
    [RibbonButton("Template", "Thư mục template", Order = 1, Large = false, Icon = "F", Color = "#6A7F3A",
        Tooltip = "Mở thư mục chứa các file .dwt (bỏ file template của bạn vào đây)")]
    public void OpenTemplateFolder()
    {
        System.Diagnostics.Process.Start("explorer.exe", TemplateFolder());
    }

    // ===================== KÝ HIỆU CHUẨN =====================

    [CommandMethod("AC_SYM_BUBBLE")]
    [RibbonButton("Ký hiệu", "Bubble trục", Group = "Ký hiệu", GroupIcon = "KÝ", Order = 0, Large = false, Icon = "①", Color = "#7B5EA7",
        Tooltip = "Vẽ bong bóng trục (vòng tròn + tên trục) theo tỉ lệ")]
    public void SymBubble()
    {
        var (ed, db, scale) = Begin();
        if (scale == null) return;
        var label = AskString(ed, "\nTên trục", "1");
        if (label == null) return;
        var pr = ed.GetPoint("\nTâm bubble: ");
        if (pr.Status != PromptStatus.OK) return;
        var c = pr.Value.TransformBy(ed.CurrentUserCoordinateSystem);
        double s = scale.Value;

        using var tr = db.TransactionManager.StartTransaction();
        var ms = ModelSpace(tr, db);
        var lay = EnsureLayer(tr, db, "S-ANNO", 7, "Continuous");
        Add(tr, ms, db, new Circle(c, Vector3d.ZAxis, 4 * s), lay);
        CenteredTxt(tr, ms, db, lay, TextStyleId(tr, db), label, c, 3.5 * s);
        tr.Commit();
    }

    [CommandMethod("AC_SYM_LEVEL")]
    [RibbonButton("Ký hiệu", "Cao độ", Group = "Ký hiệu", Order = 1, Large = false, Icon = "▽", Color = "#7B5EA7",
        Tooltip = "Vẽ ký hiệu cao độ (tam giác + đường gióng + giá trị) theo tỉ lệ")]
    public void SymLevel()
    {
        var (ed, db, scale) = Begin();
        if (scale == null) return;
        var value = AskString(ed, "\nGiá trị cao độ", "+0.000");
        if (value == null) return;
        var pr = ed.GetPoint("\nĐiểm cao độ (đỉnh tam giác): ");
        if (pr.Status != PromptStatus.OK) return;
        var p = pr.Value.TransformBy(ed.CurrentUserCoordinateSystem);
        double s = scale.Value;

        using var tr = db.TransactionManager.StartTransaction();
        var ms = ModelSpace(tr, db);
        var lay = EnsureLayer(tr, db, "S-ANNO", 7, "Continuous");
        double top = p.Y + 2.6 * s;
        var tri = new Polyline();
        tri.AddVertexAt(0, new Point2d(p.X, p.Y), 0, 0, 0);
        tri.AddVertexAt(1, new Point2d(p.X - 1.5 * s, top), 0, 0, 0);
        tri.AddVertexAt(2, new Point2d(p.X + 1.5 * s, top), 0, 0, 0);
        tri.Closed = true;
        Add(tr, ms, db, tri, lay);
        Seg(tr, ms, db, lay, p.X - 1.5 * s, top, p.X + 12 * s, top);
        Txt(tr, ms, db, lay, TextStyleId(tr, db), value, p.X + 2.5 * s, top + 0.8 * s, 2.5 * s);
        tr.Commit();
    }

    [CommandMethod("AC_SYM_NORTH")]
    [RibbonButton("Ký hiệu", "Mũi tên Bắc", Group = "Ký hiệu", Order = 2, Large = false, Icon = "N", Color = "#7B5EA7",
        Tooltip = "Vẽ mũi tên chỉ hướng Bắc theo tỉ lệ")]
    public void SymNorth()
    {
        var (ed, db, scale) = Begin();
        if (scale == null) return;
        var pr = ed.GetPoint("\nTâm mũi tên Bắc: ");
        if (pr.Status != PromptStatus.OK) return;
        var c = pr.Value.TransformBy(ed.CurrentUserCoordinateSystem);
        double s = scale.Value, R = 8 * s;

        using var tr = db.TransactionManager.StartTransaction();
        var ms = ModelSpace(tr, db);
        var lay = EnsureLayer(tr, db, "S-ANNO", 7, "Continuous");
        Add(tr, ms, db, new Circle(c, Vector3d.ZAxis, R), lay);
        var arrow = new Polyline();
        arrow.AddVertexAt(0, new Point2d(c.X, c.Y + R), 0, 0, 0);
        arrow.AddVertexAt(1, new Point2d(c.X - 0.4 * R, c.Y - 0.7 * R), 0, 0, 0);
        arrow.AddVertexAt(2, new Point2d(c.X, c.Y - 0.3 * R), 0, 0, 0);
        arrow.AddVertexAt(3, new Point2d(c.X + 0.4 * R, c.Y - 0.7 * R), 0, 0, 0);
        arrow.Closed = true;
        Add(tr, ms, db, arrow, lay);
        CenteredTxt(tr, ms, db, lay, TextStyleId(tr, db), "N", new Point3d(c.X, c.Y + R + 3 * s, 0), 3.5 * s);
        tr.Commit();
    }

    [CommandMethod("AC_SYM_NOTE")]
    [RibbonButton("Ký hiệu", "Ghi chú", Group = "Ký hiệu", Order = 3, Large = false, Icon = "Gc", Color = "#7B5EA7",
        Tooltip = "Vẽ đường dẫn từ đối tượng đến chữ ghi chú (đường gióng + gạch chân + text) theo tỉ lệ")]
    public void SymNote()
    {
        var (ed, db, scale) = Begin();
        if (scale == null) return;
        var text = AskString(ed, "\nNội dung ghi chú", "GHI CHÚ");
        if (text == null) return;
        var p1 = ed.GetPoint("\nĐiểm chỉ vào đối tượng: ");
        if (p1.Status != PromptStatus.OK) return;
        var p2 = ed.GetPoint(new PromptPointOptions("\nĐiểm đặt chữ: ") { BasePoint = p1.Value, UseBasePoint = true });
        if (p2.Status != PromptStatus.OK) return;
        var a = p1.Value.TransformBy(ed.CurrentUserCoordinateSystem);
        var b = p2.Value.TransformBy(ed.CurrentUserCoordinateSystem);
        double s = scale.Value, th = 2.5 * s;

        using var tr = db.TransactionManager.StartTransaction();
        var ms = ModelSpace(tr, db);
        var lay = EnsureLayer(tr, db, "S-ANNO", 7, "Continuous");
        double len = Math.Max(text.Length * th * 0.65, 10 * s);
        double dir = b.X >= a.X ? 1 : -1;
        Seg(tr, ms, db, lay, a.X, a.Y, b.X, b.Y);
        Seg(tr, ms, db, lay, b.X, b.Y, b.X + dir * len, b.Y);
        double tx = dir > 0 ? b.X + 0.5 * s : b.X - len + 0.5 * s;
        Txt(tr, ms, db, lay, TextStyleId(tr, db), text, tx, b.Y + 0.8 * s, th);
        tr.Commit();
    }

    // ===================== HÀM HỖ TRỢ =====================

    private static string TemplateFolder()
    {
        var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "AcadClaude", "Templates");
        Directory.CreateDirectory(dir);
        return dir;
    }

    private static (Editor ed, Database db, int? scale) Begin()
    {
        var doc = AcApp.DocumentManager.MdiActiveDocument;
        return (doc.Editor, doc.Database, AskScale(doc.Editor));
    }

    private static int? AskScale(Editor ed)
    {
        var r = ed.GetInteger(new PromptIntegerOptions("\nTỉ lệ bản vẽ 1:")
            { DefaultValue = _lastScale, UseDefaultValue = true, AllowNegative = false, AllowZero = false });
        if (r.Status != PromptStatus.OK) return null;
        _lastScale = r.Value;
        return r.Value;
    }

    private static string? AskString(Editor ed, string msg, string def)
    {
        var r = ed.GetString(new PromptStringOptions(msg) { AllowSpaces = true, DefaultValue = def, UseDefaultValue = true });
        return r.Status == PromptStatus.OK ? r.StringResult : null;
    }

    private static BlockTableRecord ModelSpace(Transaction tr, Database db)
    {
        var bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
        return (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite);
    }

    private static ObjectId TextStyleId(Transaction tr, Database db)
    {
        var tst = (TextStyleTable)tr.GetObject(db.TextStyleTableId, OpenMode.ForRead);
        return tst.Has(TextStyleName) ? tst[TextStyleName] : db.Textstyle;
    }

    private static ObjectId EnsureLayer(Transaction tr, Database db, string name, short color, string linetype)
    {
        var lt = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
        if (lt.Has(name)) return lt[name];
        lt.UpgradeOpen();
        var layer = new LayerTableRecord { Name = name, Color = Color.FromColorIndex(ColorMethod.ByAci, color) };
        var ltt = (LinetypeTable)tr.GetObject(db.LinetypeTableId, OpenMode.ForRead);
        if (!ltt.Has(linetype))
            try { db.LoadLineTypeFile(linetype, "acadiso.lin"); } catch { /* bỏ qua nếu không có */ }
        if (ltt.Has(linetype)) layer.LinetypeObjectId = ltt[linetype];
        var id = lt.Add(layer);
        tr.AddNewlyCreatedDBObject(layer, true);
        return id;
    }

    private static ObjectId Add(Transaction tr, BlockTableRecord ms, Database db, Entity ent, ObjectId layerId)
    {
        ent.SetDatabaseDefaults(db);
        ent.LayerId = layerId;
        var id = ms.AppendEntity(ent);
        tr.AddNewlyCreatedDBObject(ent, true);
        return id;
    }

    private static void Seg(Transaction tr, BlockTableRecord ms, Database db, ObjectId lay, double x1, double y1, double x2, double y2) =>
        Add(tr, ms, db, new Line(new Point3d(x1, y1, 0), new Point3d(x2, y2, 0)), lay);

    private static void Rect(Transaction tr, BlockTableRecord ms, Database db, ObjectId lay, double x0, double y0, double x1, double y1)
    {
        var pl = new Polyline();
        pl.AddVertexAt(0, new Point2d(x0, y0), 0, 0, 0);
        pl.AddVertexAt(1, new Point2d(x1, y0), 0, 0, 0);
        pl.AddVertexAt(2, new Point2d(x1, y1), 0, 0, 0);
        pl.AddVertexAt(3, new Point2d(x0, y1), 0, 0, 0);
        pl.Closed = true;
        Add(tr, ms, db, pl, lay);
    }

    private static void Txt(Transaction tr, BlockTableRecord ms, Database db, ObjectId lay, ObjectId style, string text, double x, double y, double h) =>
        Add(tr, ms, db, new DBText { TextString = text, Position = new Point3d(x, y, 0), Height = h, TextStyleId = style }, lay);

    private static void CenteredTxt(Transaction tr, BlockTableRecord ms, Database db, ObjectId lay, ObjectId style, string text, Point3d at, double h)
    {
        var t = new DBText
        {
            TextString = text, Height = h, TextStyleId = style,
            HorizontalMode = TextHorizontalMode.TextCenter, VerticalMode = TextVerticalMode.TextVerticalMid,
            Position = at, AlignmentPoint = at
        };
        Add(tr, ms, db, t, lay);
        t.AdjustAlignment(db);
    }
}
