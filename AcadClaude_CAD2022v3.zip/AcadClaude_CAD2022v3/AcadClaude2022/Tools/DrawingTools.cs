using System.Text.Json;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.Colors;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;

namespace AcadClaude.Tools;

// ======================= ĐỌC =======================

public class GetDrawingInfoTool : ToolBase
{
    public override string Name => "get_drawing_info";
    public override string Description =>
        "Lấy thông tin bản vẽ hiện tại: tên file, layer hiện hành, đơn vị (INSUNITS), số đối tượng ModelSpace, phạm vi (extents). Nên gọi đầu tiên khi chưa rõ bối cảnh.";
    protected override string SchemaJson => """{"type":"object","properties":{}}""";

    public override string Execute(JsonElement input, Document doc)
    {
        var db = doc.Database;
        using var tr = db.TransactionManager.StartTransaction();
        var ms = ModelSpace(tr, db, OpenMode.ForRead);
        int count = 0;
        foreach (ObjectId _ in ms) count++;
        var clayer = (LayerTableRecord)tr.GetObject(db.Clayer, OpenMode.ForRead);
        tr.Commit();
        return Json(new
        {
            file = doc.Name,
            activeLayer = clayer.Name,
            insunits = db.Insunits.ToString(),
            modelSpaceCount = count,
            extMin = new[] { db.Extmin.X, db.Extmin.Y },
            extMax = new[] { db.Extmax.X, db.Extmax.Y }
        });
    }
}

public class ListLayersTool : ToolBase
{
    public override string Name => "list_layers";
    public override string Description => "Liệt kê toàn bộ layer: tên, màu ACI, bật/tắt, đóng băng, khóa.";
    protected override string SchemaJson => """{"type":"object","properties":{}}""";

    public override string Execute(JsonElement input, Document doc)
    {
        var db = doc.Database;
        using var tr = db.TransactionManager.StartTransaction();
        var lt = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
        var list = new List<object>();
        foreach (ObjectId id in lt)
        {
            var l = (LayerTableRecord)tr.GetObject(id, OpenMode.ForRead);
            list.Add(new { name = l.Name, color = l.Color.ColorIndex, on = !l.IsOff, frozen = l.IsFrozen, locked = l.IsLocked });
        }
        tr.Commit();
        return Json(list);
    }
}

public class ListEntitiesTool : ToolBase
{
    public override string Name => "list_entities";
    public override string Description =>
        "Liệt kê đối tượng trong ModelSpace, lọc theo layer và/hoặc loại DXF (LINE, LWPOLYLINE, CIRCLE, TEXT, MTEXT, INSERT, HATCH, DIMENSION...). Trả về handle, loại, layer và thông tin chính.";
    protected override string SchemaJson => """
    {"type":"object","properties":{
      "layer":{"type":"string","description":"Lọc theo tên layer (để trống = tất cả)"},
      "dxf_type":{"type":"string","description":"Lọc theo loại DXF, vd LINE"},
      "limit":{"type":"integer","description":"Số lượng tối đa, mặc định 200"}}}
    """;

    public override string Execute(JsonElement input, Document doc)
    {
        string layer = S(input, "layer"), type = S(input, "dxf_type").ToUpperInvariant();
        int limit = I(input, "limit", 200);
        var db = doc.Database;
        using var tr = db.TransactionManager.StartTransaction();
        var ms = ModelSpace(tr, db, OpenMode.ForRead);
        var list = new List<object>();
        foreach (ObjectId id in ms)
        {
            if (type.Length > 0 && id.ObjectClass.DxfName != type) continue;
            var ent = (Entity)tr.GetObject(id, OpenMode.ForRead);
            if (layer.Length > 0 && !ent.Layer.Equals(layer, StringComparison.OrdinalIgnoreCase)) continue;

            object? info = ent switch
            {
                Line l => new { start = new[] { l.StartPoint.X, l.StartPoint.Y }, end = new[] { l.EndPoint.X, l.EndPoint.Y } },
                Circle c => new { center = new[] { c.Center.X, c.Center.Y }, radius = c.Radius },
                Polyline p => new { vertices = p.NumberOfVertices, closed = p.Closed, length = p.Length },
                DBText t => new { text = t.TextString, pos = new[] { t.Position.X, t.Position.Y } },
                MText m => new { text = m.Text, pos = new[] { m.Location.X, m.Location.Y } },
                BlockReference b => new { block = b.Name, pos = new[] { b.Position.X, b.Position.Y }, rotation = b.Rotation },
                _ => null
            };
            list.Add(new { handle = id.Handle.ToString(), type = id.ObjectClass.DxfName, layer = ent.Layer, info });
            if (list.Count >= limit) break;
        }
        tr.Commit();
        return Json(list);
    }
}

// ======================= GHI =======================

public class CreateLayerTool : ToolBase
{
    public override string Name => "create_layer";
    public override string Description => "Tạo layer mới hoặc cập nhật màu/linetype nếu layer đã có.";
    protected override string SchemaJson => """
    {"type":"object","properties":{
      "name":{"type":"string"},
      "color":{"type":"integer","description":"Màu ACI 1-255, mặc định 7"},
      "linetype":{"type":"string","description":"vd Continuous, CENTER, DASHED"}},
     "required":["name"]}
    """;

    public override string Execute(JsonElement input, Document doc)
    {
        var name = S(input, "name");
        var linetype = S(input, "linetype");
        var db = doc.Database;
        using var tr = db.TransactionManager.StartTransaction();
        var layer = (LayerTableRecord)tr.GetObject(EnsureLayer(tr, db, name), OpenMode.ForWrite);
        layer.Color = Color.FromColorIndex(ColorMethod.ByAci, (short)I(input, "color", 7));

        if (linetype.Length > 0)
        {
            var ltt = (LinetypeTable)tr.GetObject(db.LinetypeTableId, OpenMode.ForRead);
            if (!ltt.Has(linetype))
                try { db.LoadLineTypeFile(linetype, "acadiso.lin"); } catch { /* bỏ qua nếu không có */ }
            if (ltt.Has(linetype)) layer.LinetypeObjectId = ltt[linetype];
        }
        tr.Commit();
        return $"Layer '{name}' OK";
    }
}

public class DrawLineTool : ToolBase
{
    public override string Name => "draw_line";
    public override string Description => "Vẽ một đoạn thẳng. Trả về handle.";
    protected override string SchemaJson => """
    {"type":"object","properties":{
      "x1":{"type":"number"},"y1":{"type":"number"},"x2":{"type":"number"},"y2":{"type":"number"},
      "layer":{"type":"string"}},"required":["x1","y1","x2","y2"]}
    """;

    public override string Execute(JsonElement i, Document doc) =>
        AddEntity(doc, new Line(new Point3d(D(i, "x1"), D(i, "y1"), 0), new Point3d(D(i, "x2"), D(i, "y2"), 0)), S(i, "layer"));
}

public class DrawPolylineTool : ToolBase
{
    public override string Name => "draw_polyline";
    public override string Description => "Vẽ polyline 2D qua danh sách điểm. Dùng closed=true cho hình kín (chữ nhật, tiết diện cột...).";
    protected override string SchemaJson => """
    {"type":"object","properties":{
      "points":{"type":"array","items":{"type":"array","items":{"type":"number"},"minItems":2,"maxItems":2},"description":"[[x,y],[x,y],...]"},
      "closed":{"type":"boolean"},
      "layer":{"type":"string"}},"required":["points"]}
    """;

    public override string Execute(JsonElement i, Document doc)
    {
        var pl = new Polyline();
        int n = 0;
        foreach (var p in i.GetProperty("points").EnumerateArray())
            pl.AddVertexAt(n++, new Point2d(p[0].GetDouble(), p[1].GetDouble()), 0, 0, 0);
        pl.Closed = B(i, "closed");
        return AddEntity(doc, pl, S(i, "layer"));
    }
}

public class DrawCircleTool : ToolBase
{
    public override string Name => "draw_circle";
    public override string Description => "Vẽ đường tròn.";
    protected override string SchemaJson => """
    {"type":"object","properties":{
      "cx":{"type":"number"},"cy":{"type":"number"},"radius":{"type":"number"},
      "layer":{"type":"string"}},"required":["cx","cy","radius"]}
    """;

    public override string Execute(JsonElement i, Document doc) =>
        AddEntity(doc, new Circle(new Point3d(D(i, "cx"), D(i, "cy"), 0), Vector3d.ZAxis, D(i, "radius")), S(i, "layer"));
}

public class AddTextTool : ToolBase
{
    public override string Name => "add_text";
    public override string Description => "Thêm text một dòng. Hỗ trợ tiếng Việt nếu text style dùng font TrueType.";
    protected override string SchemaJson => """
    {"type":"object","properties":{
      "text":{"type":"string"},"x":{"type":"number"},"y":{"type":"number"},
      "height":{"type":"number","description":"Chiều cao chữ, mặc định 250"},
      "rotation_deg":{"type":"number"},
      "layer":{"type":"string"}},"required":["text","x","y"]}
    """;

    public override string Execute(JsonElement i, Document doc)
    {
        var t = new DBText
        {
            TextString = S(i, "text"),
            Position = new Point3d(D(i, "x"), D(i, "y"), 0),
            Height = D(i, "height", 250),
            Rotation = D(i, "rotation_deg") * Math.PI / 180
        };
        return AddEntity(doc, t, S(i, "layer"));
    }
}

public class DeleteEntitiesTool : ToolBase
{
    public override string Name => "delete_entities";
    public override string Description =>
        "Xóa đối tượng theo danh sách handle. CHỈ gọi sau khi người dùng đã xác nhận rõ ràng việc xóa.";
    protected override string SchemaJson => """
    {"type":"object","properties":{
      "handles":{"type":"array","items":{"type":"string"}}},"required":["handles"]}
    """;

    public override string Execute(JsonElement i, Document doc)
    {
        var db = doc.Database;
        int ok = 0;
        var failed = new List<string>();
        using var tr = db.TransactionManager.StartTransaction();
        foreach (var h in i.GetProperty("handles").EnumerateArray())
        {
            var id = HandleToId(db, h.GetString()!);
            if (id.IsNull || id.IsErased) { failed.Add(h.GetString()!); continue; }
            ((Entity)tr.GetObject(id, OpenMode.ForWrite)).Erase();
            ok++;
        }
        tr.Commit();
        return Json(new { deleted = ok, notFound = failed });
    }
}

public class ZoomExtentsTool : ToolBase
{
    public override string Name => "zoom_extents";
    public override string Description => "Zoom toàn bộ bản vẽ để người dùng xem kết quả.";
    protected override string SchemaJson => """{"type":"object","properties":{}}""";

    public override string Execute(JsonElement i, Document doc)
    {
        doc.SendStringToExecute("_.ZOOM _E ", true, false, false);
        return "OK";
    }
}
