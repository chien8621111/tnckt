using System.Text.Json;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using Polyline = Autodesk.AutoCAD.DatabaseServices.Polyline;

namespace AcadClaude.Tools;

public class ColumnDimResult
{
    public int Columns, GridVertical, GridHorizontal, LocateX, LocateY, SizeDims, SkippedNoNearbyGrid;
    public string? Error;
}

/// <summary>
/// Lõi ghi dim cột, dùng chung cho tool dim_columns (Claude) và lệnh AC_DIMCOLS (ribbon).
/// Tự nhận diện kích thước cột (bbox của polyline kín) và trục (LINE dọc/ngang) từ danh sách đối tượng đưa vào.
/// </summary>
public static class ColumnDimensioner
{
    public static ColumnDimResult Run(Database db, IEnumerable<ObjectId> candidates, string? colLayer, string? gridLayer,
        string dimLayer, bool locate, bool size, double offset, double maxGridDistance, string dimStyleName, bool dryRun)
    {
        var res = new ColumnDimResult();
        using var tr = db.TransactionManager.StartTransaction();
        var bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
        var ms = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], dryRun ? OpenMode.ForRead : OpenMode.ForWrite);

        // Nhận diện: polyline kín = cột; LINE nằm ngang/thẳng đứng = trục.
        // Nếu có chỉ định layer thì lọc thêm theo layer.
        var cols = new List<Extents3d>();
        var gridX = new List<double>();
        var gridY = new List<double>();
        foreach (var id in candidates)
        {
            var ent = tr.GetObject(id, OpenMode.ForRead) as Entity;
            if (ent == null) continue;
            if (ent is Polyline pl && pl.Closed)
            {
                if (!string.IsNullOrEmpty(colLayer) && !ent.Layer.Equals(colLayer, StringComparison.OrdinalIgnoreCase)) continue;
                cols.Add(pl.GeometricExtents);
            }
            else if (ent is Line ln)
            {
                if (!string.IsNullOrEmpty(gridLayer) && !ent.Layer.Equals(gridLayer, StringComparison.OrdinalIgnoreCase)) continue;
                double dx = Math.Abs(ln.EndPoint.X - ln.StartPoint.X), dy = Math.Abs(ln.EndPoint.Y - ln.StartPoint.Y);
                if (dx < 1e-6 * Math.Max(1, dy)) AddUnique(gridX, ln.StartPoint.X);
                else if (dy < 1e-6 * Math.Max(1, dx)) AddUnique(gridY, ln.StartPoint.Y);
            }
        }
        res.Columns = cols.Count;
        res.GridVertical = gridX.Count;
        res.GridHorizontal = gridY.Count;

        if (cols.Count == 0) { res.Error = "Không nhận diện được cột (polyline kín) nào."; return res; }
        if (locate && gridX.Count == 0 && gridY.Count == 0)
        { res.Error = "Không nhận diện được trục (LINE dọc/ngang) nào. Chọn thêm đường trục, hoặc tắt dim định vị."; return res; }

        ObjectId dimStyleId = db.Dimstyle;
        if (!string.IsNullOrEmpty(dimStyleName))
        {
            var dst = (DimStyleTable)tr.GetObject(db.DimStyleTableId, OpenMode.ForRead);
            if (!dst.Has(dimStyleName)) { res.Error = $"Không có dimstyle '{dimStyleName}'"; return res; }
            dimStyleId = dst[dimStyleName];
        }

        ObjectId layerId = ObjectId.Null;
        if (!dryRun) layerId = EnsureLayer(tr, db, dimLayer);

        void AddDim(double rot, Point3d p1, Point3d p2, Point3d line)
        {
            if (dryRun) return;
            var d = new RotatedDimension(rot, p1, p2, line, "", dimStyleId);
            d.SetDatabaseDefaults(db);
            d.DimensionStyle = dimStyleId;
            d.LayerId = layerId;
            ms.AppendEntity(d);
            tr.AddNewlyCreatedDBObject(d, true);
        }

        foreach (var e in cols)
        {
            double minX = e.MinPoint.X, maxX = e.MaxPoint.X, minY = e.MinPoint.Y, maxY = e.MaxPoint.Y;
            double cx = (minX + maxX) / 2, cy = (minY + maxY) / 2;

            if (size)
            {
                // b: dưới cột; h: bên phải cột
                AddDim(0, new Point3d(minX, minY, 0), new Point3d(maxX, minY, 0), new Point3d(cx, minY - offset, 0));
                AddDim(Math.PI / 2, new Point3d(maxX, minY, 0), new Point3d(maxX, maxY, 0), new Point3d(maxX + offset, cy, 0));
                res.SizeDims += 2;
            }

            if (locate)
            {
                // Dim ngang: trục dọc gần nhất -> tim cột, phía trên cột
                if (Nearest(gridX, cx, out double gx) && Math.Abs(gx - cx) <= maxGridDistance)
                {
                    if (Math.Abs(gx - cx) >= 1)
                    {
                        AddDim(0, new Point3d(gx, maxY, 0), new Point3d(cx, maxY, 0), new Point3d((gx + cx) / 2, maxY + offset, 0));
                        res.LocateX++;
                    }
                }
                else res.SkippedNoNearbyGrid++;

                // Dim đứng: trục ngang gần nhất -> tim cột, bên trái cột
                if (Nearest(gridY, cy, out double gy) && Math.Abs(gy - cy) <= maxGridDistance)
                {
                    if (Math.Abs(gy - cy) >= 1)
                    {
                        AddDim(Math.PI / 2, new Point3d(minX, gy, 0), new Point3d(minX, cy, 0), new Point3d(minX - offset, (gy + cy) / 2, 0));
                        res.LocateY++;
                    }
                }
                else res.SkippedNoNearbyGrid++;
            }
        }

        if (!dryRun) tr.Commit();
        return res;
    }

    private static ObjectId EnsureLayer(Transaction tr, Database db, string name)
    {
        var lt = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
        if (lt.Has(name)) return lt[name];
        lt.UpgradeOpen();
        var ltr = new LayerTableRecord { Name = name };
        var id = lt.Add(ltr);
        tr.AddNewlyCreatedDBObject(ltr, true);
        return id;
    }

    private static void AddUnique(List<double> list, double v)
    {
        if (!list.Any(x => Math.Abs(x - v) < 1)) list.Add(v);
    }

    private static bool Nearest(List<double> list, double v, out double best)
    {
        best = 0;
        if (list.Count == 0) return false;
        best = list.OrderBy(x => Math.Abs(x - v)).First();
        return true;
    }
}

/// <summary>Tool cho Claude: ghi dim định vị cột (tim cột - trục) và dim kích thước cột.</summary>
public class DimColumnsTool : ToolBase
{
    public override string Name => "dim_columns";
    public override string Description =>
        "Ghi dim cho cột. (1) Dim định vị: khoảng cách từ tim cột đến trục dọc gần nhất (dim ngang, đặt phía TRÊN cột) và đến trục ngang gần nhất " +
        "(dim đứng, đặt bên TRÁI cột). Cột nằm đúng trên trục (lệch < 1mm) thì bỏ qua dim định vị. " +
        "(2) Dim kích thước: b (dim ngang, phía DƯỚI cột) và h (dim đứng, bên PHẢI cột). " +
        "Tự nhận diện kích thước cột (polyline kín trên layer cột, mặc định S-COLS) và trục (LINE dọc/ngang trên layer trục, mặc định S-GRID). " +
        "Đơn vị mm. Dùng dry_run=true để xem trước số lượng dim sẽ tạo. Gọi 1 lần cho toàn bộ cột, không gọi lặp từng cột.";
    protected override string SchemaJson => """
    {"type":"object","properties":{
      "column_layer":{"type":"string","description":"Layer chứa cột (polyline kín), mặc định S-COLS"},
      "grid_layer":{"type":"string","description":"Layer chứa đường trục (LINE), mặc định S-GRID"},
      "dim_layer":{"type":"string","description":"Layer đặt dim, mặc định S-DIMS"},
      "handles":{"type":"array","items":{"type":"string"},"description":"Chỉ dim các cột có handle này (để trống = tất cả cột trên column_layer)"},
      "locate":{"type":"boolean","description":"Ghi dim định vị tim cột - trục, mặc định true"},
      "size":{"type":"boolean","description":"Ghi dim kích thước cột b x h, mặc định true"},
      "offset":{"type":"number","description":"Khoảng cách từ mép cột đến đường dim (mm), mặc định 500"},
      "max_grid_distance":{"type":"number","description":"Bỏ qua dim định vị nếu trục gần nhất xa hơn giá trị này (mm), mặc định 1500"},
      "dimstyle":{"type":"string","description":"Tên dimstyle, để trống = dimstyle hiện hành"},
      "dry_run":{"type":"boolean","description":"Chỉ đếm, không vẽ"}}}
    """;

    public override string Execute(JsonElement i, Document doc)
    {
        string colLayer = S(i, "column_layer", "S-COLS");
        string gridLayer = S(i, "grid_layer", "S-GRID");

        HashSet<string>? only = null;
        if (i.TryGetProperty("handles", out var hs) && hs.ValueKind == JsonValueKind.Array && hs.GetArrayLength() > 0)
            only = new HashSet<string>(hs.EnumerateArray().Select(h => h.GetString()!.ToUpperInvariant()));

        // Lấy toàn bộ đối tượng ModelSpace (cột lọc theo handle nếu có; layer lọc bên trong Run)
        var db = doc.Database;
        var ids = new List<ObjectId>();
        using (var tr = db.TransactionManager.StartTransaction())
        {
            foreach (ObjectId id in ModelSpace(tr, db, OpenMode.ForRead))
            {
                var cls = id.ObjectClass.DxfName;
                if (cls == "LWPOLYLINE")
                {
                    if (only != null && !only.Contains(id.Handle.ToString().ToUpperInvariant())) continue;
                    ids.Add(id);
                }
                else if (cls == "LINE") ids.Add(id);
            }
            tr.Commit();
        }

        var r = ColumnDimensioner.Run(db, ids, colLayer, gridLayer, S(i, "dim_layer", "S-DIMS"),
            B(i, "locate", true), B(i, "size", true), D(i, "offset", 500), D(i, "max_grid_distance", 1500),
            S(i, "dimstyle"), B(i, "dry_run"));
        if (r.Error != null) return Json(new { error = r.Error });
        return Json(new
        {
            dry_run = B(i, "dry_run"),
            columns = r.Columns,
            gridVertical = r.GridVertical,
            gridHorizontal = r.GridHorizontal,
            locateDimX = r.LocateX,
            locateDimY = r.LocateY,
            sizeDims = r.SizeDims,
            skippedNoNearbyGrid = r.SkippedNoNearbyGrid
        });
    }
}
