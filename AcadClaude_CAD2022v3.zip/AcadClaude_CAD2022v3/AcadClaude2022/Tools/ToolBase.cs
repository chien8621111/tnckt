using System.Reflection;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Nodes;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Application;

namespace AcadClaude.Tools;

/// <summary>Mọi tool đều implement interface này. Tool được tự động phát hiện bằng reflection.</summary>
public interface ITool
{
    string Name { get; }              // tên tool, dạng snake_case
    string Description { get; }       // Claude đọc mô tả này để quyết định khi nào gọi tool
    JsonObject InputSchema { get; }   // JSON Schema cho input
    string Execute(JsonElement input, Document doc); // chạy trên main thread, document đã được lock
}

public abstract class ToolBase : ITool
{
    public abstract string Name { get; }
    public abstract string Description { get; }
    protected abstract string SchemaJson { get; }
    public JsonObject InputSchema => JsonNode.Parse(SchemaJson)!.AsObject();
    public abstract string Execute(JsonElement input, Document doc);

    // ----- Đọc input -----
    protected static double D(JsonElement e, string k, double def = 0) =>
        e.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.Number ? v.GetDouble() : def;
    protected static int I(JsonElement e, string k, int def = 0) =>
        e.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.Number ? v.GetInt32() : def;
    protected static string S(JsonElement e, string k, string def = "") =>
        e.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString()! : def;
    protected static bool B(JsonElement e, string k, bool def = false) =>
        e.TryGetProperty(k, out var v) && (v.ValueKind == JsonValueKind.True || v.ValueKind == JsonValueKind.False) ? v.GetBoolean() : def;

    // ----- Trả kết quả (giữ nguyên ký tự tiếng Việt) -----
    private static readonly JsonSerializerOptions JsonOpts = new() { Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping };
    protected static string Json(object o) => JsonSerializer.Serialize(o, JsonOpts);

    // ----- Tiện ích AutoCAD -----
    protected static BlockTableRecord ModelSpace(Transaction tr, Database db, OpenMode mode)
    {
        var bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
        return (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], mode);
    }

    protected static ObjectId EnsureLayer(Transaction tr, Database db, string name)
    {
        var lt = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
        if (lt.Has(name)) return lt[name];
        lt.UpgradeOpen();
        var ltr = new LayerTableRecord { Name = name };
        var id = lt.Add(ltr);
        tr.AddNewlyCreatedDBObject(ltr, true);
        return id;
    }

    /// <summary>Thêm entity vào ModelSpace, trả về handle (hex).</summary>
    protected static string AddEntity(Document doc, Entity ent, string? layer)
    {
        var db = doc.Database;
        using var tr = db.TransactionManager.StartTransaction();
        var ms = ModelSpace(tr, db, OpenMode.ForWrite);
        ent.SetDatabaseDefaults(db);
        if (!string.IsNullOrWhiteSpace(layer)) ent.LayerId = EnsureLayer(tr, db, layer!);
        var id = ms.AppendEntity(ent);
        tr.AddNewlyCreatedDBObject(ent, true);
        tr.Commit();
        return id.Handle.ToString();
    }

    protected static ObjectId HandleToId(Database db, string handle)
    {
        var h = new Handle(Convert.ToInt64(handle, 16));
        return db.TryGetObjectId(h, out var id) ? id : ObjectId.Null;
    }
}

public static class ToolRegistry
{
    public static Dictionary<string, ITool> Tools { get; } = new();

    public static void Discover(Assembly asm)
    {
        foreach (var t in asm.GetTypes().Where(t => typeof(ITool).IsAssignableFrom(t) && !t.IsAbstract && !t.IsInterface))
        {
            var tool = (ITool)Activator.CreateInstance(t)!;
            Tools[tool.Name] = tool;
        }
    }

    /// <summary>Định nghĩa tool theo format của Anthropic API.</summary>
    public static JsonArray ToApiTools() => new(Tools.Values.Select(t => (JsonNode)new JsonObject
    {
        ["name"] = t.Name,
        ["description"] = t.Description,
        ["input_schema"] = t.InputSchema
    }).ToArray());

    /// <summary>Phải gọi từ main thread của AutoCAD (UI palette đã đảm bảo điều này).</summary>
    public static string Run(string name, JsonElement input)
    {
        if (!Tools.TryGetValue(name, out var tool)) throw new InvalidOperationException($"Không có tool '{name}'");
        var doc = AcApp.DocumentManager.MdiActiveDocument ?? throw new InvalidOperationException("Không có bản vẽ nào đang mở");
        using (doc.LockDocument())
            return tool.Execute(input, doc);
    }
}
