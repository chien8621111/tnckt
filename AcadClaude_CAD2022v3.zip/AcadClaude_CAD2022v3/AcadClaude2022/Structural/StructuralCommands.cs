using System.Globalization;
using Autodesk.AutoCAD.Colors;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.GraphicsInterface;
using Autodesk.AutoCAD.Runtime;
using AcadClaude.UI;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Application;
using Polyline = Autodesk.AutoCAD.DatabaseServices.Polyline;

// Mỗi class chứa lệnh phải được khai báo CommandClass
[assembly: CommandClass(typeof(AcadClaude.Structural.StructuralCommands))]

namespace AcadClaude.Structural;

/// <summary>
/// Các lệnh kết cấu và tiện ích. Lệnh nào có [RibbonButton] sẽ tự có nút trên ribbon.
/// Đơn vị bản vẽ giả định là mm.
/// Toàn bộ nút trong class này nằm ở tab "Kết Cấu" (đổi tên tab tại đây).
/// </summary>
[RibbonTab("Kết Cấu")]
public class StructuralCommands
{
    // ===================== KẾT CẤU =====================

    [CommandMethod("AC_GRID")]
    [RibbonButton("Kết cấu", "Lưới\ntrục", Order = 0, Icon = "#", Color = "#2E7D9A",
        Tooltip = "Vẽ lưới trục theo bước nhập (vd 3*6000,8000), có bubble, tên trục và dim")]
    public void DrawGrid()
    {
        var doc = AcApp.DocumentManager.MdiActiveDocument;
        var ed = doc.Editor;
        var db = doc.Database;

        var pr = ed.GetPoint("\nChọn điểm gốc (giao trục 1-A): ");
        if (pr.Status != PromptStatus.OK) return;
        var basePt = pr.Value.TransformBy(ed.CurrentUserCoordinateSystem);

        var xs = AskSpacings(ed, "\nBước trục dọc 1,2,3... (vd 3*6000,8000): ");
        if (xs == null) return;
        var ys = AskSpacings(ed, "\nBước trục ngang A,B,C... (vd 2*7500): ");
        if (ys == null) return;
        var r = AskDouble(ed, "\nBán kính bubble", 400);
        if (r == null) return;
        var ext = AskDouble(ed, "\nĐoạn kéo dài trục", 1500);
        if (ext == null) return;

        var X = Cumulative(xs).Select(v => basePt.X + v).ToList();
        var Y = Cumulative(ys).Select(v => basePt.Y + v).ToList();
        double xmin = X.First(), xmax = X.Last(), ymin = Y.First(), ymax = Y.Last();
        double R = r.Value, E = ext.Value, th = R * 0.875;

        using var tr = db.TransactionManager.StartTransaction();
        var ms = ModelSpace(tr, db);
        var lGrid = EnsureLayer(tr, db, "S-GRID", 8, "CENTER");
        var lAnno = EnsureLayer(tr, db, "S-ANNO", 7);
        var lDims = EnsureLayer(tr, db, "S-DIMS", 6);

        // Trục dọc + bubble phía dưới
        for (int i = 0; i < X.Count; i++)
        {
            Add(tr, ms, db, new Line(P(X[i], ymin - E), P(X[i], ymax + E)), lGrid);
            var c = P(X[i], ymin - E - R);
            Add(tr, ms, db, new Circle(c, Vector3d.ZAxis, R), lAnno);
            AddCenteredText(tr, ms, db, (i + 1).ToString(), c, th, lAnno);
        }

        // Trục ngang + bubble bên trái
        for (int j = 0; j < Y.Count; j++)
        {
            Add(tr, ms, db, new Line(P(xmin - E, Y[j]), P(xmax + E, Y[j])), lGrid);
            var c = P(xmin - E - R, Y[j]);
            Add(tr, ms, db, new Circle(c, Vector3d.ZAxis, R), lAnno);
            AddCenteredText(tr, ms, db, Letter(j), c, th, lAnno);
        }

        // Dim chi tiết + dim tổng
        double yd1 = ymin - E - 2 * R - 2 * R, yd2 = yd1 - 2 * R;
        double xd1 = xmin - E - 2 * R - 2 * R, xd2 = xd1 - 2 * R;
        for (int i = 0; i + 1 < X.Count; i++)
            AddDim(tr, ms, db, 0, P(X[i], ymin), P(X[i + 1], ymin), P(0, yd1), lDims);
        for (int j = 0; j + 1 < Y.Count; j++)
            AddDim(tr, ms, db, Math.PI / 2, P(xmin, Y[j]), P(xmin, Y[j + 1]), P(xd1, 0), lDims);
        if (X.Count > 2) AddDim(tr, ms, db, 0, P(xmin, ymin), P(xmax, ymin), P(0, yd2), lDims);
        if (Y.Count > 2) AddDim(tr, ms, db, Math.PI / 2, P(xmin, ymin), P(xmin, ymax), P(xd2, 0), lDims);

        tr.Commit();
        ed.WriteMessage($"\nĐã vẽ lưới {X.Count} trục dọc x {Y.Count} trục ngang.");
    }

    [CommandMethod("AC_DIMCOLS")]
    [RibbonButton("Kết cấu", "Dim\ncột", Order = 1, Icon = "D", Color = "#B5452F",
        Tooltip = "Quét chọn cột (polyline kín) và trục (LINE); tự nhận diện kích thước cột, trục, rồi ghi dim định vị tim cột - trục và dim kích thước cột")]
    public void DimColumns()
    {
        var doc = AcApp.DocumentManager.MdiActiveDocument;
        var ed = doc.Editor;

        var filter = new SelectionFilter(new[] { new TypedValue((int)DxfCode.Start, "LWPOLYLINE,LINE") });
        var sel = ed.GetSelection(new PromptSelectionOptions { MessageForAdding = "\nQuét chọn cột và đường trục: " }, filter);
        if (sel.Status != PromptStatus.OK) return;

        var r = AcadClaude.Tools.ColumnDimensioner.Run(doc.Database, sel.Value.GetObjectIds(), null, null,
            "S-DIMS", locate: true, size: true, offset: 500, maxGridDistance: 1500, dimStyleName: "", dryRun: false);
        if (r.Error != null) { ed.WriteMessage("\n" + r.Error); return; }

        ed.WriteMessage($"\nNhận diện {r.Columns} cột, {r.GridVertical} trục dọc, {r.GridHorizontal} trục ngang. " +
            $"Đã ghi {r.LocateX + r.LocateY} dim định vị, {r.SizeDims} dim kích thước (layer S-DIMS)." +
            (r.SkippedNoNearbyGrid > 0 ? $" Bỏ qua {r.SkippedNoNearbyGrid} dim định vị do không có trục gần (<1500mm)." : ""));
    }

    [CommandMethod("AC_COLS")]
    public void ColumnsAtIntersections()
    {
        var doc = AcApp.DocumentManager.MdiActiveDocument;
        var ed = doc.Editor;
        var db = doc.Database;

        var b = AskDouble(ed, "\nCạnh cột b (theo X)", 400);
        if (b == null) return;
        var h = AskDouble(ed, "\nCạnh cột h (theo Y)", 400);
        if (h == null) return;

        var filter = new SelectionFilter(new[] { new TypedValue((int)DxfCode.Start, "LINE") });
        var sel = ed.GetSelection(new PromptSelectionOptions { MessageForAdding = "\nChọn các đường trục: " }, filter);
        if (sel.Status != PromptStatus.OK) return;

        using var tr = db.TransactionManager.StartTransaction();
        var lines = sel.Value.GetObjectIds().Select(id => (Line)tr.GetObject(id, OpenMode.ForRead)).ToList();

        // Tìm giao điểm, bỏ điểm trùng
        var pts = new List<Point3d>();
        for (int i = 0; i < lines.Count; i++)
            for (int j = i + 1; j < lines.Count; j++)
            {
                var col = new Point3dCollection();
                lines[i].IntersectWith(lines[j], Intersect.OnBothOperands, col, IntPtr.Zero, IntPtr.Zero);
                foreach (Point3d p in col)
                    if (!pts.Any(q => q.DistanceTo(p) < 1)) pts.Add(p);
            }

        var ms = ModelSpace(tr, db);
        var lCols = EnsureLayer(tr, db, "S-COLS", 1);
        double hb = b.Value / 2, hh = h.Value / 2;

        foreach (var p in pts)
        {
            var pl = new Polyline();
            pl.AddVertexAt(0, new Point2d(p.X - hb, p.Y - hh), 0, 0, 0);
            pl.AddVertexAt(1, new Point2d(p.X + hb, p.Y - hh), 0, 0, 0);
            pl.AddVertexAt(2, new Point2d(p.X + hb, p.Y + hh), 0, 0, 0);
            pl.AddVertexAt(3, new Point2d(p.X - hb, p.Y + hh), 0, 0, 0);
            pl.Closed = true;
            var plId = Add(tr, ms, db, pl, lCols);

            var hatch = new Hatch();
            Add(tr, ms, db, hatch, lCols);
            hatch.SetHatchPattern(HatchPatternType.PreDefined, "SOLID");
            hatch.Associative = false;
            hatch.AppendLoop(HatchLoopTypes.Outermost, new ObjectIdCollection { plId });
            hatch.EvaluateHatch(true);
        }

        tr.Commit();
        ed.WriteMessage($"\nĐã vẽ {pts.Count} cột {b}x{h} trên layer S-COLS.");
    }

    [CommandMethod("AC_LAYERS")]
    [RibbonButton("Kết cấu", "Bộ layer KC", Order = 10, Large = false, Icon = "L", Color = "#6A7F3A",
        Tooltip = "Tạo bộ layer kết cấu chuẩn: S-GRID, S-COLS, S-BEAM, S-WALL, S-SLAB, S-ANNO, S-DIMS")]
    public void CreateLayers()
    {
        var doc = AcApp.DocumentManager.MdiActiveDocument;
        var db = doc.Database;
        (string name, short color, string lt)[] layers =
        {
            ("S-GRID", 8, "CENTER"), ("S-COLS", 1, "Continuous"), ("S-BEAM", 3, "Continuous"),
            ("S-WALL", 2, "Continuous"), ("S-SLAB", 4, "Continuous"), ("S-ANNO", 7, "Continuous"),
            ("S-DIMS", 6, "Continuous")
        };
        using var tr = db.TransactionManager.StartTransaction();
        foreach (var (n, c, lt) in layers) EnsureLayer(tr, db, n, c, lt);
        tr.Commit();
        doc.Editor.WriteMessage($"\nĐã tạo/cập nhật {layers.Length} layer kết cấu.");
    }

    // ===================== TIỆN ÍCH =====================

    [CommandMethod("AC_COUNT", CommandFlags.UsePickSet)]
    [RibbonButton("Tiện ích", "Đếm đối tượng", Group = "Tiện ích", GroupIcon = "T", Order = 0, Large = false, Icon = "N", Color = "#7B5EA7",
        Tooltip = "Đếm đối tượng đã chọn theo layer và loại")]
    public void CountObjects()
    {
        var doc = AcApp.DocumentManager.MdiActiveDocument;
        var ed = doc.Editor;
        var sel = ed.GetSelection();
        if (sel.Status != PromptStatus.OK) return;

        using var tr = doc.Database.TransactionManager.StartTransaction();
        var rows = sel.Value.GetObjectIds()
            .Select(id => (Entity)tr.GetObject(id, OpenMode.ForRead))
            .GroupBy(e => (e.Layer, Type: e.GetRXClass().DxfName))
            .OrderBy(g => g.Key.Layer).ThenBy(g => g.Key.Type);
        tr.Commit();

        ed.WriteMessage($"\n{"Layer",-25}{"Loại",-15}{"Số lượng",10}");
        foreach (var g in rows)
            ed.WriteMessage($"\n{g.Key.Layer,-25}{g.Key.Type,-15}{g.Count(),10}");
        ed.WriteMessage($"\nTổng: {sel.Value.Count} đối tượng.");
        AcApp.DisplayTextScreen = true;
    }

    [CommandMethod("AC_AREA", CommandFlags.UsePickSet)]
    [RibbonButton("Tiện ích", "Tổng diện tích", Group = "Tiện ích", Order = 1, Large = false, Icon = "A", Color = "#7B5EA7",
        Tooltip = "Cộng diện tích polyline kín, circle, hatch, region đã chọn (đơn vị mm -> m²)")]
    public void SumArea()
    {
        var doc = AcApp.DocumentManager.MdiActiveDocument;
        var ed = doc.Editor;
        var filter = new SelectionFilter(new[] { new TypedValue((int)DxfCode.Start, "LWPOLYLINE,CIRCLE,HATCH,REGION,ELLIPSE") });
        var sel = ed.GetSelection(filter);
        if (sel.Status != PromptStatus.OK) return;

        double sum = 0;
        int n = 0;
        using var tr = doc.Database.TransactionManager.StartTransaction();
        foreach (var id in sel.Value.GetObjectIds())
        {
            var ent = tr.GetObject(id, OpenMode.ForRead);
            double? a = ent switch
            {
                Polyline p when p.Closed => p.Area,
                Circle c => c.Area,
                Ellipse el => el.Area,
                Hatch hc => hc.Area,
                Region rg => rg.Area,
                _ => null
            };
            if (a != null) { sum += a.Value; n++; }
        }
        tr.Commit();
        ed.WriteMessage($"\n{n} đối tượng, tổng diện tích = {sum:N0} mm² = {sum / 1e6:N3} m²");
    }

    [CommandMethod("AC_FONTVN")]
    [RibbonButton("Tiện ích", "Font tiếng Việt", Group = "Tiện ích", Order = 2, Large = false, Icon = "Ă", Color = "#7B5EA7",
        Tooltip = "Đổi các text style đang dùng font .shx sang Arial để hiện đúng tiếng Việt")]
    public void FixVietnameseFont()
    {
        var doc = AcApp.DocumentManager.MdiActiveDocument;
        var ed = doc.Editor;
        var kw = new PromptKeywordOptions("\nĐổi mọi text style font .shx sang Arial? [Co/Khong]", "Co Khong") { AllowNone = false };
        var res = ed.GetKeywords(kw);
        if (res.Status != PromptStatus.OK || res.StringResult != "Co") return;

        int n = 0;
        using var tr = doc.Database.TransactionManager.StartTransaction();
        var tst = (TextStyleTable)tr.GetObject(doc.Database.TextStyleTableId, OpenMode.ForRead);
        foreach (ObjectId id in tst)
        {
            var s = (TextStyleTableRecord)tr.GetObject(id, OpenMode.ForRead);
            if (s.IsShapeFile || s.IsDependent) continue;
            if (!s.FileName.EndsWith(".shx", StringComparison.OrdinalIgnoreCase) && s.FileName.Length > 0) continue;
            s.UpgradeOpen();
            s.FileName = "arial.ttf";
            s.BigFontFileName = "";
            s.Font = new FontDescriptor("Arial", false, false, 0, 0);
            n++;
        }
        tr.Commit();
        ed.Regen();
        ed.WriteMessage($"\nĐã đổi {n} text style sang Arial.");
    }

    // ===================== HÀM HỖ TRỢ =====================

    private static Point3d P(double x, double y) => new(x, y, 0);

    private static BlockTableRecord ModelSpace(Transaction tr, Database db)
    {
        var bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
        return (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite);
    }

    private static ObjectId Add(Transaction tr, BlockTableRecord ms, Database db, Entity ent, ObjectId layerId)
    {
        ent.SetDatabaseDefaults(db);
        ent.LayerId = layerId;
        var id = ms.AppendEntity(ent);
        tr.AddNewlyCreatedDBObject(ent, true);
        return id;
    }

    private static void AddCenteredText(Transaction tr, BlockTableRecord ms, Database db, string text, Point3d at, double height, ObjectId layerId)
    {
        var t = new DBText
        {
            TextString = text,
            Height = height,
            HorizontalMode = TextHorizontalMode.TextCenter,
            VerticalMode = TextVerticalMode.TextVerticalMid,
            Position = at,
            AlignmentPoint = at
        };
        Add(tr, ms, db, t, layerId);
        t.AdjustAlignment(db);
    }

    private static void AddDim(Transaction tr, BlockTableRecord ms, Database db, double rot, Point3d p1, Point3d p2, Point3d dimLine, ObjectId layerId)
    {
        var d = new RotatedDimension(rot, p1, p2, dimLine, "", db.Dimstyle);
        Add(tr, ms, db, d, layerId);
    }

    private static ObjectId EnsureLayer(Transaction tr, Database db, string name, short color, string linetype = "Continuous")
    {
        var lt = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
        LayerTableRecord layer;
        if (lt.Has(name))
            return lt[name];

        lt.UpgradeOpen();
        layer = new LayerTableRecord { Name = name, Color = Color.FromColorIndex(ColorMethod.ByAci, color) };
        var ltt = (LinetypeTable)tr.GetObject(db.LinetypeTableId, OpenMode.ForRead);
        if (!ltt.Has(linetype))
            try { db.LoadLineTypeFile(linetype, "acadiso.lin"); } catch { /* bỏ qua */ }
        if (ltt.Has(linetype)) layer.LinetypeObjectId = ltt[linetype];
        var id = lt.Add(layer);
        tr.AddNewlyCreatedDBObject(layer, true);
        return id;
    }

    private static double? AskDouble(Editor ed, string msg, double def)
    {
        var r = ed.GetDouble(new PromptDoubleOptions(msg)
            { DefaultValue = def, UseDefaultValue = true, AllowNegative = false, AllowZero = false });
        return r.Status == PromptStatus.OK ? r.Value : null;
    }

    /// <summary>Đọc chuỗi bước trục: "6000,6000,8000" hoặc "3*6000,8000" (dùng * hoặc x).</summary>
    private static List<double>? AskSpacings(Editor ed, string msg)
    {
        var r = ed.GetString(new PromptStringOptions(msg) { AllowSpaces = false });
        if (r.Status != PromptStatus.OK || string.IsNullOrWhiteSpace(r.StringResult)) return null;
        var list = new List<double>();
        foreach (var token in r.StringResult.Split(new[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries))
        {
            var parts = token.ToLowerInvariant().Split('*', 'x');
            if (parts.Length == 2 && int.TryParse(parts[0], out var cnt)
                && double.TryParse(parts[1], NumberStyles.Float, CultureInfo.InvariantCulture, out var v))
                list.AddRange(Enumerable.Repeat(v, cnt));
            else if (double.TryParse(token, NumberStyles.Float, CultureInfo.InvariantCulture, out var v1))
                list.Add(v1);
            else
            {
                ed.WriteMessage($"\nKhông hiểu '{token}'.");
                return null;
            }
        }
        return list;
    }

    private static List<double> Cumulative(List<double> steps)
    {
        var res = new List<double> { 0 };
        foreach (var s in steps) res.Add(res[res.Count - 1] + s);
        return res;
    }

    /// <summary>0 -> A, 25 -> Z, 26 -> AA ...</summary>
    private static string Letter(int i)
    {
        var s = "";
        i++;
        while (i > 0) { i--; s = (char)('A' + i % 26) + s; i /= 26; }
        return s;
    }
}
