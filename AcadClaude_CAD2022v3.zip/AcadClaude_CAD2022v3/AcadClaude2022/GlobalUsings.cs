// Bổ sung using cho .NET Framework 4.8 (ImplicitUsings không đủ namespace trên net48)
global using System;
global using System.Collections.Generic;
global using System.IO;
global using System.Linq;
global using System.Threading;
global using System.Threading.Tasks;

// Shim để dùng record/init trên .NET Framework 4.8
namespace System.Runtime.CompilerServices
{
    internal static class IsExternalInit { }
}
