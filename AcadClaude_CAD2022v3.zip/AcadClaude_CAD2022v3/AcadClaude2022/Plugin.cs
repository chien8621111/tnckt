using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.Windows;
using AcadClaude.Mcp;
using AcadClaude.Tools;
using AcadClaude.UI;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Application;

[assembly: ExtensionApplication(typeof(AcadClaude.Plugin))]
[assembly: CommandClass(typeof(AcadClaude.Commands))]

namespace AcadClaude;

public class Plugin : IExtensionApplication
{
    public void Initialize()
    {
        // .NET Framework: bật TLS 1.2 để gọi được api.anthropic.com
        System.Net.ServicePointManager.SecurityProtocol |= System.Net.SecurityProtocolType.Tls12;

        // Nạp các DLL phụ thuộc (System.Text.Json, System.Memory...) từ thư mục của plugin,
        // tránh xung đột phiên bản với DLL mà AutoCAD đã nạp sẵn.
        AppDomain.CurrentDomain.AssemblyResolve += ResolveFromPluginFolder;

        ToolRegistry.Discover(typeof(Plugin).Assembly);
        RibbonSetup.Init();   // tạo tab "Claude AI" trên ribbon

        string mcp;
        try { BridgeServer.Start(); mcp = $"MCP bật ở cổng {BridgeServer.Port}"; }
        catch (System.Exception ex) { mcp = "MCP không khởi động được: " + ex.Message; }

        AcApp.DocumentManager.MdiActiveDocument?.Editor.WriteMessage(
            $"\n[AcadClaude] Đã nạp {ToolRegistry.Tools.Count} tool. {mcp}. Gõ CLAUDE để mở.\n");
    }

    public void Terminate() => BridgeServer.Stop();

    private static System.Reflection.Assembly? ResolveFromPluginFolder(object? sender, ResolveEventArgs args)
    {
        var name = new System.Reflection.AssemblyName(args.Name).Name;
        var loaded = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(a => a.GetName().Name == name);
        if (loaded != null) return loaded;
        var dir = Path.GetDirectoryName(typeof(Plugin).Assembly.Location)!;
        var file = Path.Combine(dir, name + ".dll");
        return File.Exists(file) ? System.Reflection.Assembly.LoadFrom(file) : null;
    }
}

public class Commands
{
    private static PaletteSet? _palette;

    [CommandMethod("CLAUDE")]
    public void ShowPalette()
    {
        if (_palette == null)
        {
            _palette = new PaletteSet("Claude for AutoCAD", new Guid("7d3c1a52-4f0e-4b8e-9a61-2c5e8f1d0b37"))
            {
                MinimumSize = new System.Drawing.Size(320, 420),
                DockEnabled = DockSides.Left | DockSides.Right,
                KeepFocus = true
            };
            _palette.AddVisual("Chat", new ChatView());
            _palette.AddVisual("Tools", new ToolsView());
        }
        _palette.Visible = true;
    }

    [CommandMethod("CLAUDEKEY")]
    public void SetApiKey()
    {
        var ed = AcApp.DocumentManager.MdiActiveDocument.Editor;
        var res = ed.GetString(new PromptStringOptions("\nNhập Anthropic API key: ") { AllowSpaces = false });
        if (res.Status != PromptStatus.OK || string.IsNullOrWhiteSpace(res.StringResult)) return;
        Config.ApiKey = res.StringResult.Trim();
        ed.WriteMessage("\nĐã lưu API key.\n");
    }

    [CommandMethod("CLAUDEMODEL")]
    public void SetModel()
    {
        var ed = AcApp.DocumentManager.MdiActiveDocument.Editor;
        var res = ed.GetString(new PromptStringOptions($"\nModel hiện tại: {Config.Model}. Nhập model mới: ") { AllowSpaces = false });
        if (res.Status != PromptStatus.OK || string.IsNullOrWhiteSpace(res.StringResult)) return;
        Config.Model = res.StringResult.Trim();
        ed.WriteMessage($"\nĐã chuyển sang {Config.Model}.\n");
    }

    [CommandMethod("CLAUDEMCP")]
    public void ToggleMcp()
    {
        var ed = AcApp.DocumentManager.MdiActiveDocument.Editor;
        if (BridgeServer.IsRunning)
        {
            BridgeServer.Stop();
            ed.WriteMessage("\nĐã TẮT cổng MCP. Gõ CLAUDEMCP lần nữa để bật lại.\n");
            return;
        }
        try
        {
            BridgeServer.Start();
            ed.WriteMessage($"\nĐã BẬT cổng MCP tại http://localhost:{BridgeServer.Port}/\n");
        }
        catch (System.Exception ex) { ed.WriteMessage("\nKhông bật được MCP: " + ex.Message + "\n"); }
    }
}
