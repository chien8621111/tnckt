using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using AcadClaude.Tools;

namespace AcadClaude.Claude;

/// <summary>
/// Gọi Anthropic Messages API với vòng lặp tool use.
/// Phải được gọi từ UI thread của palette: các await sẽ quay về đúng main thread của AutoCAD,
/// nhờ vậy tool được chạy an toàn trên bản vẽ.
/// </summary>
public class ClaudeClient
{
    private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromMinutes(5) };
    private readonly JsonArray _messages = new();

    public event Action<string>? OnText;
    public event Action<string, string, bool>? OnToolCall; // tên tool, kết quả, có lỗi hay không

    private const string SystemPrompt = """
        Bạn là trợ lý tích hợp trong AutoCAD, hỗ trợ kỹ sư kết cấu/BIM tại Việt Nam.
        - Trả lời bằng tiếng Việt, ngắn gọn.
        - Đơn vị bản vẽ mặc định là mm, trừ khi get_drawing_info cho biết khác.
        - Khi chưa rõ bối cảnh, gọi get_drawing_info hoặc list_layers trước.
        - Trước khi xóa hoặc sửa nhiều đối tượng, mô tả việc sẽ làm và chờ người dùng xác nhận.
        - Sau khi vẽ xong, tóm tắt những gì đã tạo (số lượng, layer).
        """;

    public void Reset() => _messages.Clear();

    public async Task SendAsync(string userText, int maxSteps = 25)
    {
        if (string.IsNullOrWhiteSpace(Config.ApiKey))
            throw new InvalidOperationException("Chưa có API key. Gõ lệnh CLAUDEKEY trong AutoCAD.");

        _messages.Add(new JsonObject { ["role"] = "user", ["content"] = userText });

        for (int step = 0; step < maxSteps; step++)
        {
            var body = new JsonObject
            {
                ["model"] = Config.Model,
                ["max_tokens"] = 8192,
                ["system"] = SystemPrompt,
                ["tools"] = ToolRegistry.ToApiTools(),
                ["messages"] = _messages.DeepClone()
            };

            using var req = new HttpRequestMessage(HttpMethod.Post, "https://api.anthropic.com/v1/messages")
            {
                Content = new StringContent(body.ToJsonString(), Encoding.UTF8, "application/json")
            };
            req.Headers.Add("x-api-key", Config.ApiKey);
            req.Headers.Add("anthropic-version", "2023-06-01");
            req.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            using var resp = await Http.SendAsync(req);
            var json = await resp.Content.ReadAsStringAsync();
            if (!resp.IsSuccessStatusCode)
            {
                if (step == 0) _messages.RemoveAt(_messages.Count - 1); // bỏ câu hỏi lỗi để hội thoại không hỏng
                throw new Exception($"API lỗi {(int)resp.StatusCode}: {json}");
            }

            var root = JsonNode.Parse(json)!;
            var content = root["content"]!.AsArray();
            _messages.Add(new JsonObject { ["role"] = "assistant", ["content"] = content.DeepClone() });

            var toolResults = new JsonArray();
            foreach (var block in content)
            {
                switch ((string?)block!["type"])
                {
                    case "text":
                        OnText?.Invoke((string)block["text"]!);
                        break;

                    case "tool_use":
                        var name = (string)block["name"]!;
                        var input = JsonSerializer.Deserialize<JsonElement>(block["input"]!.ToJsonString());
                        string output;
                        bool isError = false;
                        try { output = ToolRegistry.Run(name, input); }
                        catch (Exception ex) { output = ex.Message; isError = true; }
                        OnToolCall?.Invoke(name, output, isError);
                        toolResults.Add(new JsonObject
                        {
                            ["type"] = "tool_result",
                            ["tool_use_id"] = (string)block["id"]!,
                            ["content"] = output,
                            ["is_error"] = isError
                        });
                        break;
                }
            }

            if ((string?)root["stop_reason"] != "tool_use") return;
            _messages.Add(new JsonObject { ["role"] = "user", ["content"] = toolResults });
        }

        OnText?.Invoke($"(Đã dừng sau {maxSteps} bước gọi tool.)");
    }
}
