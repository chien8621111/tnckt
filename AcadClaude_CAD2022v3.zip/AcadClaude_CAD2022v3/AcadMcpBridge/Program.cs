// AcadMcpBridge: MCP server (giao thức stdio, JSON-RPC mỗi dòng một message).
// Claude Desktop / Claude Code chạy file exe này; nó chuyển tiếp tới plugin AcadClaude
// đang chạy trong AutoCAD qua http://localhost:8765. Danh sách tool lấy trực tiếp từ plugin,
// nên tool mới viết trong plugin tự xuất hiện ở đây.
using System.Text;
using System.Text.Json.Nodes;

const string BaseUrl = "http://localhost:8765";
const string StatusTool = "autocad_status";

var http = new HttpClient { Timeout = TimeSpan.FromMinutes(3) };
var stdout = new StreamWriter(Console.OpenStandardOutput(), new UTF8Encoding(false)) { AutoFlush = true };
var stdin = new StreamReader(Console.OpenStandardInput(), new UTF8Encoding(false));
var writeLock = new object();
var initialized = false;
var lastToolNames = "";

void Send(JsonNode msg)
{
    var line = msg.ToJsonString();
    lock (writeLock) { stdout.Write(line); stdout.Write('\n'); }
}

void Log(string text) => Console.Error.WriteLine("[AcadMcpBridge] " + text);

string Token()
{
    try
    {
        var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "AcadClaude", "config.json");
        return (string?)JsonNode.Parse(File.ReadAllText(path))?["mcpToken"] ?? "";
    }
    catch { return ""; }
}

HttpRequestMessage Req(HttpMethod method, string path, JsonNode? body = null)
{
    var req = new HttpRequestMessage(method, BaseUrl + path);
    req.Headers.Add("X-AcadClaude-Token", Token());
    if (body != null) req.Content = new StringContent(body.ToJsonString(), Encoding.UTF8, "application/json");
    return req;
}

async Task<JsonArray?> FetchToolsAsync()
{
    try
    {
        using var resp = await http.SendAsync(Req(HttpMethod.Get, "/tools"));
        if (!resp.IsSuccessStatusCode) return null;
        return JsonNode.Parse(await resp.Content.ReadAsStringAsync())?.AsArray();
    }
    catch { return null; }
}

JsonArray ToMcpTools(JsonArray? apiTools)
{
    var list = new JsonArray();
    if (apiTools != null)
        foreach (var t in apiTools)
            list.Add(new JsonObject
            {
                ["name"] = t!["name"]!.DeepClone(),
                ["description"] = t["description"]!.DeepClone(),
                ["inputSchema"] = t["input_schema"]!.DeepClone()
            });

    list.Add(new JsonObject
    {
        ["name"] = StatusTool,
        ["description"] = "Kiểm tra kết nối tới AutoCAD (plugin AcadClaude) và bản vẽ đang mở. " +
                          "Gọi khi không thấy các tool AutoCAD hoặc tool báo lỗi kết nối.",
        ["inputSchema"] = new JsonObject { ["type"] = "object", ["properties"] = new JsonObject() }
    });
    return list;
}

JsonObject ToolResult(string text, bool isError) => new()
{
    ["content"] = new JsonArray(new JsonObject { ["type"] = "text", ["text"] = text }),
    ["isError"] = isError
};

const string NotConnected =
    "Không kết nối được AutoCAD. Hãy mở AutoCAD, NETLOAD AcadClaude.dll, " +
    "và kiểm tra command line có dòng 'MCP bật ở cổng 8765' (hoặc gõ CLAUDEMCP để bật).";

async Task<JsonObject> CallToolAsync(string name, JsonNode? args)
{
    try
    {
        if (name == StatusTool)
        {
            using var s = await http.SendAsync(Req(HttpMethod.Get, "/status"));
            var st = JsonNode.Parse(await s.Content.ReadAsStringAsync());
            if (s.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                return ToolResult("AutoCAD từ chối: sai token. Hãy NETLOAD lại plugin rồi khởi động lại Claude.", true);
            var docName = (string?)st?["document"];
            return ToolResult(string.IsNullOrEmpty(docName)
                ? "Đã kết nối AutoCAD nhưng chưa có bản vẽ nào đang mở."
                : $"Đã kết nối AutoCAD. Bản vẽ đang mở: {docName}. Số tool: {st?["tools"]}.", false);
        }

        var body = new JsonObject { ["name"] = name, ["input"] = args?.DeepClone() ?? new JsonObject() };
        using var resp = await http.SendAsync(Req(HttpMethod.Post, "/call", body));
        var res = JsonNode.Parse(await resp.Content.ReadAsStringAsync());
        var ok = (bool?)res?["ok"] == true;
        return ToolResult(ok ? (string?)res?["output"] ?? "" : (string?)res?["error"] ?? "Lỗi không rõ", !ok);
    }
    catch (HttpRequestException) { return ToolResult(NotConnected, true); }
    catch (TaskCanceledException) { return ToolResult("AutoCAD không phản hồi kịp (quá 3 phút).", true); }
}

async Task<JsonNode?> HandleAsync(string method, JsonNode? prms)
{
    switch (method)
    {
        case "initialize":
            return new JsonObject
            {
                ["protocolVersion"] = (string?)prms?["protocolVersion"] ?? "2025-06-18",
                ["capabilities"] = new JsonObject { ["tools"] = new JsonObject { ["listChanged"] = true } },
                ["serverInfo"] = new JsonObject { ["name"] = "autocad", ["version"] = "0.1.0" },
                ["instructions"] = "Các tool này điều khiển bản vẽ đang mở trong AutoCAD. Đơn vị mặc định là mm. " +
                                   "Gọi get_drawing_info trước khi vẽ nếu chưa rõ bối cảnh. Hỏi xác nhận trước khi xóa."
            };

        case "ping":
            return new JsonObject();

        case "tools/list":
            var tools = await FetchToolsAsync();
            if (tools == null) Log("Chưa kết nối được AutoCAD khi lấy danh sách tool.");
            return new JsonObject { ["tools"] = ToMcpTools(tools) };

        case "tools/call":
            var name = (string?)prms?["name"] ?? "";
            return await CallToolAsync(name, prms?["arguments"]);

        default:
            throw new MissingMethodException(method);
    }
}

// Định kỳ kiểm tra danh sách tool; khi AutoCAD mở/tắt hoặc plugin đổi tool thì báo Claude tải lại
async Task PollAsync()
{
    while (true)
    {
        await Task.Delay(5000);
        var tools = await FetchToolsAsync();
        var names = tools == null ? "" : string.Join(",", tools.Select(t => (string?)t?["name"]));
        if (names != lastToolNames)
        {
            lastToolNames = names;
            if (initialized)
                Send(new JsonObject { ["jsonrpc"] = "2.0", ["method"] = "notifications/tools/list_changed" });
        }
    }
}

Log("Đã khởi động, kết nối tới " + BaseUrl);
_ = Task.Run(PollAsync);

string? line;
while ((line = await stdin.ReadLineAsync()) != null)
{
    if (string.IsNullOrWhiteSpace(line)) continue;
    JsonNode? msg;
    try { msg = JsonNode.Parse(line); }
    catch { Log("Bỏ qua dòng không phải JSON"); continue; }

    var method = (string?)msg?["method"] ?? "";
    var id = msg?["id"]?.DeepClone();

    if (id == null) // notification, không cần trả lời
    {
        if (method == "notifications/initialized") initialized = true;
        continue;
    }

    var prms = msg?["params"]?.DeepClone();
    _ = Task.Run(async () =>
    {
        try
        {
            var result = await HandleAsync(method, prms);
            Send(new JsonObject { ["jsonrpc"] = "2.0", ["id"] = id, ["result"] = result });
        }
        catch (MissingMethodException)
        {
            Send(new JsonObject
            {
                ["jsonrpc"] = "2.0", ["id"] = id,
                ["error"] = new JsonObject { ["code"] = -32601, ["message"] = "Method not found: " + method }
            });
        }
        catch (Exception ex)
        {
            Send(new JsonObject
            {
                ["jsonrpc"] = "2.0", ["id"] = id,
                ["error"] = new JsonObject { ["code"] = -32603, ["message"] = ex.Message }
            });
        }
    });
}
