# AcadMcpBridge: MCP server cho AutoCAD

Claude Desktop / Claude Code  <-- stdio (MCP) -->  AcadMcpBridge.exe  <-- http://localhost:8765 -->  plugin AcadClaude trong AutoCAD

- Danh sách tool lấy trực tiếp từ plugin: viết tool mới trong plugin là Claude Desktop thấy ngay (tự cập nhật sau ~5 giây).
- Thêm tool `autocad_status` để kiểm tra kết nối.
- Bảo mật: chỉ nghe trên localhost, có token lưu ở %APPDATA%\AcadClaude\config.json.

## Build
    cd AcadMcpBridge
    dotnet build -c Release
File chạy: bin\Release\net8.0\AcadMcpBridge.exe

## Claude Desktop
Settings -> Developer -> Edit Config, thêm vào claude_desktop_config.json:

    {
      "mcpServers": {
        "autocad": {
          "command": "D:\\AI CAD\\AcadClaude_CAD2022\\AcadMcpBridge\\bin\\Release\\net8.0\\AcadMcpBridge.exe"
        }
      }
    }

## Claude Code
    claude mcp add autocad -- "D:\AI CAD\AcadClaude_CAD2022\AcadMcpBridge\bin\Release\net8.0\AcadMcpBridge.exe"
